import { applyChessMove, chessStatus, initialChess, type ChessState, } from '@mesapop/shared';
import type { GameModule } from './module';
interface ChessAction {
    from: number;
    to: number;
    promotion?: 'q' | 'r' | 'b' | 'n';
}
export const chessModule: GameModule<ChessState, ChessAction> = {
    slug: 'xadrez',
    minPlayers: 2,
    maxPlayers: 2,
    allowSpectators: true,
    rotation: true,
    init() {
        return initialChess();
    },
    play(state, seat, action) {
        if (typeof action?.from !== 'number' ||
            typeof action?.to !== 'number' ||
            action.from < 0 ||
            action.from > 63 ||
            action.to < 0 ||
            action.to > 63) {
            return { error: 'Jogada inválida' };
        }
        return applyChessMove(state, seat, {
            from: action.from,
            to: action.to,
            promotion: action.promotion,
        });
    },
    getStateFor(state) {
        return state;
    },
    result(state) {
        const status = chessStatus(state);
        return {
            finished: status.kind !== 'playing',
            winnerSeats: status.kind === 'checkmate' ? [status.winner] : [],
            draw: status.kind !== 'playing' && status.kind !== 'checkmate',
        };
    },
};
