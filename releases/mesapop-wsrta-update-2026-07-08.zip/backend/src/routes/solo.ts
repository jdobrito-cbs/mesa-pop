import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
const PLAUSIBILITY: Record<string, {
    maxPerSec: number;
    minMs: number;
    maxPoints: number;
}> = {
    'esquadrao-1942': { maxPerSec: 400, minMs: 4000, maxPoints: 2000000 },
    'nave-espacial': { maxPerSec: 15, minMs: 3000, maxPoints: 200000 },
    cardume: { maxPerSec: 80, minMs: 5000, maxPoints: 500000 },
    snake: { maxPerSec: 30, minMs: 2000, maxPoints: 50000 },
    'campo-minado': { maxPerSec: 150, minMs: 2500, maxPoints: 2000 },
    invasores: { maxPerSec: 80, minMs: 4000, maxPoints: 1000000 },
    'come-come': { maxPerSec: 120, minMs: 4000, maxPoints: 500000 },
    'pega-ladrao': { maxPerSec: 100, minMs: 4000, maxPoints: 300000 },
    'missao-elevador': { maxPerSec: 120, minMs: 5000, maxPoints: 500000 },
    paciencia: { maxPerSec: 30, minMs: 25000, maxPoints: 2000 },
    puzzle: { maxPerSec: 80, minMs: 15000, maxPoints: 10000 },
    memoria: { maxPerSec: 60, minMs: 15000, maxPoints: 2000 },
    sudoku: { maxPerSec: 60, minMs: 25000, maxPoints: 2500 },
    'caca-palavras': { maxPerSec: 50, minMs: 20000, maxPoints: 1500 },
    cruzadinha: { maxPerSec: 40, minMs: 30000, maxPoints: 2200 },
};
const startBody = z.object({ gameSlug: z.string().trim().min(1) });
const finishBody = z.object({
    matchId: z.string().trim().min(1),
    points: z.number().int().min(0),
});
export default async function soloRoutes(app: FastifyInstance) {
    app.post('/api/solo/start', { preHandler: [app.authenticate] }, async (req, reply) => {
        if (req.auth!.guest) {
            return reply.code(403).send({ error: 'LOGIN_REQUIRED', message: 'Crie sua conta para pontuar no ranking' });
        }
        const { gameSlug } = startBody.parse(req.body);
        const userId = req.auth!.sub;
        const game = await app.prisma.game.findUnique({ where: { slug: gameSlug } });
        if (!game || !game.isEnabled || !PLAUSIBILITY[gameSlug]) {
            return reply.code(400).send({ error: 'INVALID_GAME', message: 'Jogo indisponível' });
        }
        await app.prisma.match.updateMany({
            where: {
                gameId: game.id,
                status: 'IN_PROGRESS',
                roomId: null,
                players: { some: { userId } },
            },
            data: { status: 'ABANDONED', endedAt: new Date() },
        });
        const match = await app.prisma.match.create({
            data: {
                gameId: game.id,
                players: { create: { userId } },
            },
        });
        return reply.code(201).send({ matchId: match.id });
    });
    app.post('/api/solo/finish', { preHandler: [app.authenticate] }, async (req, reply) => {
        if (req.auth!.guest) {
            return reply.code(403).send({ error: 'LOGIN_REQUIRED', message: 'Crie sua conta para pontuar no ranking' });
        }
        const { matchId, points } = finishBody.parse(req.body);
        const userId = req.auth!.sub;
        const match = await app.prisma.match.findUnique({
            where: { id: matchId },
            include: { game: true, players: true },
        });
        if (!match ||
            match.status !== 'IN_PROGRESS' ||
            match.roomId !== null ||
            !match.players.some((p) => p.userId === userId)) {
            return reply.code(400).send({ error: 'INVALID_MATCH', message: 'Partida inválida' });
        }
        const rules = PLAUSIBILITY[match.game.slug];
        if (!rules) {
            return reply.code(400).send({ error: 'INVALID_GAME', message: 'Jogo indisponível' });
        }
        const elapsedMs = Date.now() - match.startedAt.getTime();
        const cap = Math.min((elapsedMs / 1000) * rules.maxPerSec, rules.maxPoints);
        if (elapsedMs < rules.minMs || points > cap) {
            await app.prisma.match.update({
                where: { id: matchId },
                data: { status: 'ABANDONED', endedAt: new Date() },
            });
            return reply.code(422).send({
                error: 'IMPLAUSIBLE_SCORE',
                message: 'Pontuação rejeitada pela validação do servidor',
            });
        }
        await app.prisma.match.update({
            where: { id: matchId },
            data: { status: 'FINISHED', endedAt: new Date() },
        });
        await app.prisma.matchPlayer.updateMany({
            where: { matchId, userId },
            data: { score: points },
        });
        await app.prisma.score.create({
            data: {
                userId,
                gameId: match.gameId,
                points,
                metadata: { durationMs: elapsedMs },
            },
        });
        const best = await app.prisma.score.aggregate({
            where: { userId, gameId: match.gameId },
            _max: { points: true },
        });
        const bests = await app.prisma.score.groupBy({
            by: ['userId'],
            where: { gameId: match.gameId },
            _max: { points: true },
        });
        const myBest = best._max.points ?? points;
        const rank = bests.filter((b) => (b._max.points ?? 0) > myBest).length + 1;
        return { points, best: myBest, rank, isRecord: points >= myBest };
    });
    app.get('/api/leaderboards/:slug', async (req, reply) => {
        const { slug } = req.params as {
            slug: string;
        };
        const q = z
            .object({ days: z.coerce.number().int().min(1).max(365).default(30) })
            .parse(req.query);
        const game = await app.prisma.game.findUnique({ where: { slug } });
        if (!game)
            return reply.code(404).send({ error: 'NOT_FOUND', message: 'Jogo não encontrado' });
        const since = new Date(Date.now() - q.days * 24 * 60 * 60 * 1000);
        const bests = await app.prisma.score.groupBy({
            by: ['userId'],
            where: { gameId: game.id, createdAt: { gte: since } },
            _max: { points: true },
        });
        bests.sort((a, b) => (b._max.points ?? 0) - (a._max.points ?? 0));
        const rankedUsers = await app.prisma.user.findMany({
            where: { id: { in: bests.map((b) => b.userId) }, isGuest: false },
            select: { id: true, displayName: true, username: true },
        });
        const nameOf = new Map(rankedUsers.map((u) => [u.id, u.username ?? u.displayName]));
        const top = bests.filter((b) => nameOf.has(b.userId)).slice(0, 20);
        return {
            days: q.days,
            rows: top.map((b, i) => ({
                rank: i + 1,
                userId: b.userId,
                displayName: nameOf.get(b.userId) ?? '—',
                points: b._max.points ?? 0,
            })),
        };
    });
}
