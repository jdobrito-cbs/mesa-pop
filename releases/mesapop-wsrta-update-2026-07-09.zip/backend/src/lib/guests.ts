import type { PrismaClient } from '@prisma/client';
export async function deleteGuest(prisma: PrismaClient, userId: string): Promise<void> {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user || !user.isGuest)
        return;
    await prisma.room.deleteMany({ where: { hostId: userId } });
    await prisma.user.delete({ where: { id: userId } }).catch(() => { });
}
export async function reapOldGuests(prisma: PrismaClient, olderThanHours = 12): Promise<number> {
    const limite = new Date(Date.now() - olderThanHours * 3600000);
    const velhos = await prisma.user.findMany({
        where: { isGuest: true, createdAt: { lt: limite } },
        select: { id: true },
    });
    for (const g of velhos)
        await deleteGuest(prisma, g.id);
    return velhos.length;
}
export function inicioDoMes(d = new Date()): Date {
    return new Date(d.getFullYear(), d.getMonth(), 1);
}
