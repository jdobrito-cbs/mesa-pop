import { buildApp } from './app';
import { config } from './config';
import { reapOldGuests } from './lib/guests';
const app = await buildApp();
const guestReaper = setInterval(() => {
    reapOldGuests(app.prisma, 12).catch((err) => app.log.warn({ err }, 'reap de convidados falhou'));
}, 60 * 60 * 1000);
guestReaper.unref();
try {
    await app.listen({ port: config.port, host: config.host });
}
catch (err) {
    app.log.error(err);
    process.exit(1);
}
