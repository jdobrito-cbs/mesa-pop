export interface RoomPlayerView {
    userId: string;
    displayName: string;
    isConnected: boolean;
    seat: number | null;
    isBot?: boolean;
}
export type RoomStatusView = 'WAITING' | 'PLAYING' | 'FINISHED' | 'CLOSED';
export interface SpectatorView {
    userId: string;
    displayName: string;
    isConnected: boolean;
}
export interface RoomFeatures {
    seatPicking: boolean;
    spectators: boolean;
    rotation: boolean;
}
export interface RoomView {
    id: string;
    code: string;
    gameSlug: string;
    gameName: string;
    isPrivate: boolean;
    status: RoomStatusView;
    hostId: string;
    maxPlayers: number;
    players: RoomPlayerView[];
    spectators: SpectatorView[];
    features: RoomFeatures;
    options: Record<string, unknown> | null;
}
export interface ChatMessageView {
    id: string;
    userId: string;
    displayName: string;
    text: string;
    at: string;
}
export interface GameEndView {
    winnerUserIds: string[];
    draw: boolean;
    reason: 'normal' | 'wo';
}
export interface Ack<T = unknown> {
    ok: boolean;
    error?: string;
    data?: T;
}
export interface ClientEvents {
    'room:create': (input: {
        gameSlug: string;
        isPrivate: boolean;
        options?: Record<string, unknown>;
    }, ack: (res: Ack<RoomView>) => void) => void;
    'room:createVsBot': (input: {
        gameSlug: string;
        options?: Record<string, unknown>;
    }, ack: (res: Ack<RoomView>) => void) => void;
    'room:join': (input: {
        code: string;
    }, ack: (res: Ack<RoomView>) => void) => void;
    'room:leave': (ack: (res: Ack) => void) => void;
    'room:start': (ack: (res: Ack) => void) => void;
    'room:seat': (input: {
        seat?: number;
        team?: 0 | 1;
    }, ack: (res: Ack) => void) => void;
    'game:action': (input: {
        action: unknown;
    }, ack: (res: Ack) => void) => void;
    'chat:send': (input: {
        text: string;
    }, ack: (res: Ack) => void) => void;
}
export interface ServerEvents {
    'room:update': (room: RoomView) => void;
    'game:state': (payload: {
        state: unknown;
        yourSeat: number;
    }) => void;
    'game:end': (payload: GameEndView) => void;
    'chat:message': (message: ChatMessageView) => void;
    'chat:history': (messages: ChatMessageView[]) => void;
}
