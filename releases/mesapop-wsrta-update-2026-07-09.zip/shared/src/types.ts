export type Role = 'USER' | 'ADMIN';
export interface UserPublic {
    id: string;
    email: string;
    username: string | null;
    name: string;
    displayName: string;
    phone: string;
    role: Role;
    avatarUrl: string | null;
    isGuest: boolean;
    createdAt: string;
}
export interface AuthResponse {
    user: UserPublic;
    accessToken: string;
}
export interface ApiError {
    error: string;
    message: string;
    details?: unknown;
}
