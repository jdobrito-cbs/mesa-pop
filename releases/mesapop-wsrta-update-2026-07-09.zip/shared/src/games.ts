export type GameFamily = 'TURN' | 'PARTY' | 'PUZZLE' | 'ARCADE' | 'ACTION' | 'ECONOMY' | 'FLOCKING';
export interface GameDef {
    slug: string;
    name: string;
    description: string;
    family: GameFamily;
    minPlayers: number;
    maxPlayers: number;
    color: string;
    icon: string;
    phase: number;
    enabled: boolean;
}
export const GAME_CATALOG: GameDef[] = [
    { slug: 'damas', name: 'Damas', description: 'O clássico jogo de tabuleiro para dois.', family: 'TURN', minPlayers: 2, maxPlayers: 2, color: 'pop-purple', icon: '⚫', phase: 2, enabled: false },
    { slug: 'domino', name: 'Dominó', description: 'Quatro jogadores, em duplas, na mesa.', family: 'TURN', minPlayers: 4, maxPlayers: 4, color: 'pop-cyan', icon: '🁢', phase: 3, enabled: false },
    { slug: 'one', name: 'One', description: 'Descarte tudo antes dos rivais. Cuidado com o +4!', family: 'TURN', minPlayers: 2, maxPlayers: 4, color: 'pop-orange', icon: '🃏', phase: 3, enabled: false },
    { slug: 'esquadrao-1942', name: 'Esquadrão 42', description: 'Shoot\'em up aéreo com chuva de power-ups.', family: 'ACTION', minPlayers: 1, maxPlayers: 1, color: 'pop-yellow', icon: '✈️', phase: 4, enabled: true },
    { slug: 'nave-espacial', name: 'Desvio Estelar', description: 'Desvie de tudo. Sobreviva o máximo que puder.', family: 'ARCADE', minPlayers: 1, maxPlayers: 1, color: 'pop-purple', icon: '🚀', phase: 4, enabled: true },
    { slug: 'esquadrao-coop', name: 'Esquadrão 42 Co-op', description: 'Dois aviões, um céu hostil. Reanime o parceiro e sobrevivam juntos.', family: 'ACTION', minPlayers: 2, maxPlayers: 2, color: 'pop-orange', icon: '🛩️', phase: 5, enabled: true },
    { slug: 'fazenda', name: 'Fazenda Pop', description: 'Plante, colha, venda e cresça — até offline.', family: 'ECONOMY', minPlayers: 1, maxPlayers: 1, color: 'pop-green', icon: '🌾', phase: 6, enabled: true },
    { slug: 'cardume', name: 'Cardume', description: 'Comande um cardume vivo contra peixes gigantes.', family: 'FLOCKING', minPlayers: 1, maxPlayers: 1, color: 'pop-cyan', icon: '🐠', phase: 6, enabled: true },
    { slug: 'corrida', name: 'Corrida Pop', description: 'Carro ou moto em 3ª pessoa, com drift e boost. Até 4.', family: 'ACTION', minPlayers: 2, maxPlayers: 4, color: 'pop-orange', icon: '🏎️', phase: 7, enabled: true },
    { slug: 'xadrez', name: 'Xadrez', description: 'O jogo dos reis — com espectadores e fila.', family: 'TURN', minPlayers: 2, maxPlayers: 2, color: 'pop-purple', icon: '♞', phase: 8, enabled: true },
    { slug: 'truco', name: 'Truco', description: 'Blefe, grite truco e vire a mesa.', family: 'TURN', minPlayers: 2, maxPlayers: 4, color: 'pop-orange', icon: '🂡', phase: 8, enabled: true },
    { slug: 'stop', name: 'Stop!', description: 'Adedanha com os amigos: pense rápido!', family: 'PARTY', minPlayers: 2, maxPlayers: 6, color: 'pop-yellow', icon: '✏️', phase: 8, enabled: true },
    { slug: 'desenha-adivinha', name: 'Desenha & Adivinha', description: 'Desenhe a palavra secreta em 3 min — quem acerta, pontua.', family: 'PARTY', minPlayers: 3, maxPlayers: 6, color: 'pop-green', icon: '🎨', phase: 8, enabled: true },
    { slug: 'campo-minado', name: 'Campo Minado', description: 'Lógica pura: revele tudo sem pisar numa mina.', family: 'PUZZLE', minPlayers: 1, maxPlayers: 1, color: 'pop-cyan', icon: '💣', phase: 8, enabled: true },
    { slug: 'termo-diario', name: 'Palavra do Dia', description: 'Uma palavra por dia. Compare com os amigos.', family: 'PUZZLE', minPlayers: 1, maxPlayers: 1, color: 'pop-green', icon: '🔤', phase: 8, enabled: true },
    { slug: 'snake', name: 'Snake', description: 'Coma, cresça, não se morda. Clássico eterno.', family: 'ARCADE', minPlayers: 1, maxPlayers: 1, color: 'pop-green', icon: '🐍', phase: 8, enabled: true },
    { slug: 'paciencia', name: 'Paciência', description: 'O clássico solitário de cartas para relaxar.', family: 'PUZZLE', minPlayers: 1, maxPlayers: 1, color: 'pop-magenta', icon: '🃑', phase: 8, enabled: true },
    { slug: 'puzzle', name: 'Puzzle', description: 'Monte o quebra-cabeça no menor tempo.', family: 'PUZZLE', minPlayers: 1, maxPlayers: 1, color: 'pop-yellow', icon: '🧩', phase: 8, enabled: true },
    { slug: 'missao-elevador', name: 'Missão Elevador', description: 'Desça o prédio de elevador, porta a porta, sem ser visto.', family: 'ARCADE', minPlayers: 1, maxPlayers: 1, color: 'pop-purple', icon: '🛗', phase: 8, enabled: true },
    { slug: 'pega-ladrao', name: 'Pega-Ladrão', description: 'Persiga o ladrão pelos andares da loja antes que ele fuja.', family: 'ARCADE', minPlayers: 1, maxPlayers: 1, color: 'pop-orange', icon: '👮', phase: 8, enabled: true },
    { slug: 'come-come', name: 'Come-Come', description: 'Limpe o labirinto sem virar lanche dos fantasmas.', family: 'ARCADE', minPlayers: 1, maxPlayers: 1, color: 'pop-yellow', icon: '🟡', phase: 8, enabled: true },
    { slug: 'invasores', name: 'Invasores', description: 'Segure as fileiras alienígenas antes que desçam até você.', family: 'ARCADE', minPlayers: 1, maxPlayers: 1, color: 'pop-green', icon: '👾', phase: 8, enabled: true },
    { slug: 'duelo-palavras', name: 'Duelo de Palavras', description: 'A mesma palavra secreta para todos — quem acerta primeiro leva.', family: 'PARTY', minPlayers: 2, maxPlayers: 6, color: 'pop-cyan', icon: '🔠', phase: 8, enabled: true },
    { slug: 'memoria', name: 'Jogo da Memória', description: 'Ache os pares — com amigos ou solo contra o relógio.', family: 'TURN', minPlayers: 2, maxPlayers: 4, color: 'pop-cyan', icon: '🧠', phase: 9, enabled: true },
    { slug: 'pife', name: 'Pife', description: 'Nove cartas, três jogos de três. Bata primeiro!', family: 'TURN', minPlayers: 2, maxPlayers: 4, color: 'pop-green', icon: '🂠', phase: 9, enabled: true },
    { slug: 'sudoku', name: 'Sudoku', description: 'Lógica pura em 3 níveis — todo puzzle tem solução única.', family: 'PUZZLE', minPlayers: 1, maxPlayers: 1, color: 'pop-purple', icon: '🔢', phase: 9, enabled: true },
    { slug: 'caca-palavras', name: 'Caça-palavras', description: 'Ache as 10 palavras escondidas na sopa de letras.', family: 'PUZZLE', minPlayers: 1, maxPlayers: 1, color: 'pop-yellow', icon: '🔍', phase: 9, enabled: true },
    { slug: 'forca', name: 'Forca', description: 'Escolha a palavra secreta — ou escape dela, letra a letra.', family: 'PARTY', minPlayers: 2, maxPlayers: 6, color: 'pop-magenta', icon: '😵', phase: 9, enabled: true },
    { slug: 'bingo', name: 'Bingo', description: 'Bolas cantadas ao vivo — marque a cartela e grite BINGO!', family: 'PARTY', minPlayers: 2, maxPlayers: 16, color: 'pop-orange', icon: '🎱', phase: 9, enabled: true },
    { slug: 'quiz-pop', name: 'Quiz Pop', description: '10 perguntas, 15 segundos cada — rapidez vale bônus!', family: 'PARTY', minPlayers: 2, maxPlayers: 8, color: 'pop-cyan', icon: '❓', phase: 9, enabled: true },
    { slug: 'quiz-nostalgia', name: 'Quiz Nostalgia', description: 'Música, novelas e o Brasil de antigamente — quem lembra, leva.', family: 'PARTY', minPlayers: 2, maxPlayers: 8, color: 'pop-magenta', icon: '📺', phase: 9, enabled: true },
    { slug: 'cruzadinha', name: 'Cruzadinha', description: 'Palavras-cruzadas de dicas curtas, geradas na hora.', family: 'PUZZLE', minPlayers: 1, maxPlayers: 1, color: 'pop-green', icon: '✏️', phase: 9, enabled: true },
    { slug: 'mahjong', name: 'Mahjong', description: 'Combine pares de peças livres até esvaziar a mesa — 3 níveis.', family: 'PUZZLE', minPlayers: 1, maxPlayers: 1, color: 'pop-orange', icon: '🀄', phase: 9, enabled: true },
    { slug: 'ganso', name: 'Corrida do Ganso', description: 'Trilha clássica com dados — casas especiais e sorte. Até 4, ou contra o robô.', family: 'TURN', minPlayers: 2, maxPlayers: 4, color: 'pop-yellow', icon: '🦢', phase: 9, enabled: true },
    { slug: 'gira-genio', name: 'Gira Gênio', description: 'Roleta de 6 categorias — acerte e junte as coroas. Até 6, ou contra o robô.', family: 'PARTY', minPlayers: 2, maxPlayers: 6, color: 'pop-purple', icon: '🎡', phase: 9, enabled: true },
];
