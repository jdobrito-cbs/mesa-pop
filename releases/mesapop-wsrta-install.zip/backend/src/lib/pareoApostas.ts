import type { PrismaClient } from '@prisma/client';
import { PAREO_APOSTAS_FICHAS, PAREO_CAUDA_MS, PAREO_CAVALOS, PAREO_CORRIDA_MS, PAREO_ODDS, pareoBuildRace, } from '@mesapop/shared';
import type { PareoState } from '../games/pareo';
export type ApostaErro = 'FASE_ERRADA' | 'PAREO_TROCOU' | 'VALOR_INVALIDO' | 'CAVALO_INVALIDO' | 'JA_APOSTOU' | 'SEM_FICHAS';
export interface ApostaOk {
    betId: string;
    lane: number;
    valor: number;
    odds: number;
    fichas: number;
}
export async function registrarAposta(prisma: PrismaClient, opts: {
    userId: string;
    roomId: string;
    state: PareoState;
    numero: number;
    lane: number;
    valor: number;
}): Promise<{
    erro: ApostaErro;
} | ApostaOk> {
    const { userId, roomId, state, numero, lane, valor } = opts;
    if (state.fase !== 'apostas')
        return { erro: 'FASE_ERRADA' };
    if (numero !== state.numero)
        return { erro: 'PAREO_TROCOU' };
    if (!Number.isInteger(lane) || lane < 0 || lane >= PAREO_CAVALOS.length)
        return { erro: 'CAVALO_INVALIDO' };
    if (!PAREO_APOSTAS_FICHAS.includes(valor))
        return { erro: 'VALOR_INVALIDO' };
    const jaTem = await prisma.pareoBet.findUnique({
        where: { roomId_numero_userId: { roomId, numero, userId } },
    });
    if (jaTem)
        return { erro: 'JA_APOSTOU' };
    const debitado = await prisma.user.updateMany({
        where: { id: userId, isGuest: false, fichas: { gte: valor } },
        data: { fichas: { decrement: valor } },
    });
    if (debitado.count === 0)
        return { erro: 'SEM_FICHAS' };
    const odds = PAREO_ODDS[lane]!;
    const liquidaEm = new Date(state.largadaEm + PAREO_CORRIDA_MS + PAREO_CAUDA_MS);
    try {
        const bet = await prisma.pareoBet.create({
            data: { userId, roomId, numero, seed: state.seed, lane, valor, odds, liquidaEm },
        });
        const user = await prisma.user.findUnique({ where: { id: userId }, select: { fichas: true } });
        return { betId: bet.id, lane, valor, odds, fichas: user?.fichas ?? 0 };
    }
    catch {
        await prisma.user.update({ where: { id: userId }, data: { fichas: { increment: valor } } });
        return { erro: 'JA_APOSTOU' };
    }
}
export async function liquidarApostas(prisma: PrismaClient, agora = new Date()): Promise<{
    liquidadas: number;
    pagas: number;
}> {
    const vencidas = await prisma.pareoBet.findMany({
        where: { resultado: 'pendente', liquidaEm: { lte: agora } },
        take: 500,
    });
    let pagas = 0;
    const vencedorPorSeed = new Map<number, number>();
    for (const bet of vencidas) {
        let vencedor = vencedorPorSeed.get(bet.seed);
        if (vencedor === undefined) {
            vencedor = pareoBuildRace(bet.seed).vencedor;
            vencedorPorSeed.set(bet.seed, vencedor);
        }
        const ganhou = bet.lane === vencedor;
        const payout = ganhou ? Math.round(bet.valor * bet.odds) : 0;
        const marcada = await prisma.pareoBet.updateMany({
            where: { id: bet.id, resultado: 'pendente' },
            data: { resultado: ganhou ? 'ganhou' : 'perdeu', payout },
        });
        if (marcada.count === 0)
            continue;
        if (payout > 0) {
            await prisma.user.update({ where: { id: bet.userId }, data: { fichas: { increment: payout } } });
            pagas++;
        }
    }
    return { liquidadas: vencidas.length, pagas };
}
