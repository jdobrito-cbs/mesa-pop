import crypto from 'node:crypto';
import { PAREO_APOSTAS_MS, PAREO_CAUDA_MS, PAREO_CAVALOS, PAREO_CERIMONIA_MS, PAREO_CORRIDA_MS, PAREO_PRELARGADA_MS, pareoBuildRace, type PareoFase, type PareoView, } from '@mesapop/shared';
import type { GameModule } from './module';
export interface PareoState {
    numero: number;
    fase: PareoFase;
    faseFimEm: number;
    largadaEm: number;
    seed: number;
    vencedor: number;
    winCrossT: number;
    historico: string[];
}
function corridaMs(winCrossT: number): number {
    return Math.min(PAREO_CORRIDA_MS, Math.round(winCrossT * PAREO_CORRIDA_MS) + PAREO_CAUDA_MS);
}
export function novoPareo(numero: number, historico: string[], agora = Date.now()): PareoState {
    const seed = crypto.randomInt(1, 2147483646);
    const corrida = pareoBuildRace(seed);
    const apostasMs = Number(process.env.PAREO_APOSTAS_MS ?? PAREO_APOSTAS_MS);
    const prelargadaMs = Number(process.env.PAREO_PRELARGADA_MS ?? PAREO_PRELARGADA_MS);
    return {
        numero,
        fase: 'apostas',
        faseFimEm: agora + apostasMs,
        largadaEm: agora + apostasMs + prelargadaMs,
        seed,
        vencedor: corrida.vencedor,
        winCrossT: corrida.winCrossT,
        historico,
    };
}
export function avancaCiclo(s: PareoState, agora = Date.now()): void {
    while (agora >= s.faseFimEm) {
        if (s.fase === 'apostas') {
            s.fase = 'prelargada';
            s.faseFimEm = s.largadaEm;
        }
        else if (s.fase === 'prelargada') {
            s.fase = 'corrida';
            s.faseFimEm = s.largadaEm + corridaMs(s.winCrossT);
        }
        else if (s.fase === 'corrida') {
            s.fase = 'cerimonia';
            s.faseFimEm = s.largadaEm + PAREO_CORRIDA_MS + PAREO_CERIMONIA_MS;
            s.historico = [PAREO_CAVALOS[s.vencedor]!.nome, ...s.historico].slice(0, 8);
        }
        else {
            const prox = novoPareo(s.numero + 1, s.historico, s.faseFimEm);
            Object.assign(s, prox);
        }
    }
}
function viewDe(s: PareoState): PareoView {
    return {
        numero: s.numero,
        fase: s.fase,
        faseFimEm: s.faseFimEm,
        largadaEm: s.largadaEm,
        agora: Date.now(),
        seed: s.fase === 'corrida' || s.fase === 'cerimonia' ? s.seed : null,
        vencedor: s.fase === 'cerimonia' ? s.vencedor : null,
        historico: s.historico,
    };
}
export const pareoModule: GameModule<PareoState, unknown> = {
    slug: 'pareo',
    minPlayers: 1,
    maxPlayers: 16,
    allowSpectators: true,
    realtime: { tickMs: 500, broadcastEvery: 4 },
    init() {
        return novoPareo(1, []);
    },
    tick(state) {
        avancaCiclo(state);
    },
    play() {
        return { error: 'As apostas chegam em breve — por ora, escolha seu favorito e torça!' };
    },
    getStateFor(state) {
        return viewDe(state);
    },
    result() {
        return { finished: false, winnerSeats: [], draw: false };
    },
};
