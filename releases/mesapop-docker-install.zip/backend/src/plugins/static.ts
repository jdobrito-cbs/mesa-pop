import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import fp from 'fastify-plugin';
import fastifyStatic from '@fastify/static';
export default fp(async (app) => {
    const here = path.dirname(fileURLToPath(import.meta.url));
    const dist = path.resolve(here, '../../../frontend/dist');
    const indexHtml = path.join(dist, 'index.html');
    if (!fs.existsSync(indexHtml))
        return;
    await app.register(fastifyStatic, { root: dist, wildcard: false });
    app.setNotFoundHandler((req, reply) => {
        if (req.method !== 'GET' || req.url.startsWith('/api') || req.url.startsWith('/socket.io')) {
            return reply.code(404).send({ error: 'NOT_FOUND', message: 'Rota não encontrada' });
        }
        return reply.type('text/html').send(fs.readFileSync(indexHtml));
    });
});
