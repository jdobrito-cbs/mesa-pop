export const PLAUSIBILITY: Record<string, {
    maxPerSec: number;
    minMs: number;
    maxPoints: number;
}> = {
    'esquadrao-1942': { maxPerSec: 400, minMs: 4000, maxPoints: 2000000 },
    'nave-espacial': { maxPerSec: 15, minMs: 3000, maxPoints: 200000 },
    cardume: { maxPerSec: 80, minMs: 5000, maxPoints: 500000 },
    snake: { maxPerSec: 30, minMs: 2000, maxPoints: 50000 },
    'campo-minado': { maxPerSec: 150, minMs: 2500, maxPoints: 2000 },
    invasores: { maxPerSec: 80, minMs: 4000, maxPoints: 1000000 },
    'come-come': { maxPerSec: 120, minMs: 4000, maxPoints: 500000 },
    'pega-ladrao': { maxPerSec: 100, minMs: 4000, maxPoints: 300000 },
    'missao-elevador': { maxPerSec: 120, minMs: 5000, maxPoints: 500000 },
    paciencia: { maxPerSec: 30, minMs: 25000, maxPoints: 2000 },
    puzzle: { maxPerSec: 80, minMs: 15000, maxPoints: 10000 },
    memoria: { maxPerSec: 60, minMs: 15000, maxPoints: 2000 },
    sudoku: { maxPerSec: 60, minMs: 25000, maxPoints: 2500 },
    'caca-palavras': { maxPerSec: 50, minMs: 20000, maxPoints: 1500 },
    cruzadinha: { maxPerSec: 40, minMs: 30000, maxPoints: 2200 },
    mahjong: { maxPerSec: 40, minMs: 20000, maxPoints: 5000 },
};
