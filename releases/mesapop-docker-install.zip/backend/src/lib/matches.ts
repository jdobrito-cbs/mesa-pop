import type { PrismaClient } from '@prisma/client';
export async function abandonarPartidasOrfas(prisma: PrismaClient): Promise<number> {
    const r = await prisma.match.updateMany({
        where: { status: 'IN_PROGRESS' },
        data: { status: 'ABANDONED', endedAt: new Date() },
    });
    return r.count;
}
export async function fecharSalasOrfas(prisma: PrismaClient): Promise<number> {
    const r = await prisma.room.updateMany({
        where: { status: { in: ['WAITING', 'PLAYING'] } },
        data: { status: 'CLOSED', closedAt: new Date() },
    });
    return r.count;
}
export async function reapSoloParadas(prisma: PrismaClient, minutos = 30): Promise<number> {
    const limite = new Date(Date.now() - minutos * 60000);
    const r = await prisma.match.updateMany({
        where: { status: 'IN_PROGRESS', roomId: null, startedAt: { lt: limite } },
        data: { status: 'ABANDONED', endedAt: new Date() },
    });
    return r.count;
}
