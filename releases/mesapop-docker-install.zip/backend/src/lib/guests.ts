import type { PrismaClient } from '@prisma/client';
export async function deleteGuest(prisma: PrismaClient, userId: string): Promise<void> {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user || !user.isGuest)
        return;
    await prisma.room.deleteMany({ where: { hostId: userId } });
    await prisma.user.delete({ where: { id: userId } }).catch(() => { });
}
const saidasPendentes = new Map<string, NodeJS.Timeout>();
export function scheduleGuestLeave(prisma: PrismaClient, userId: string, opts?: {
    graceMs?: number;
    aindaOnline?: () => boolean;
}): void {
    const ms = opts?.graceMs ?? Number(process.env.GUEST_LEAVE_GRACE_MS ?? 90000);
    cancelGuestLeave(userId);
    if (ms <= 0) {
        void deleteGuest(prisma, userId);
        return;
    }
    const timer = setTimeout(() => {
        saidasPendentes.delete(userId);
        if (opts?.aindaOnline?.())
            return;
        void deleteGuest(prisma, userId);
    }, ms);
    timer.unref?.();
    saidasPendentes.set(userId, timer);
}
export function cancelGuestLeave(userId: string): void {
    const timer = saidasPendentes.get(userId);
    if (timer) {
        clearTimeout(timer);
        saidasPendentes.delete(userId);
    }
}
export async function reapOldGuests(prisma: PrismaClient, olderThanHours = 12): Promise<number> {
    const limite = new Date(Date.now() - olderThanHours * 3600000);
    const velhos = await prisma.user.findMany({
        where: { isGuest: true, createdAt: { lt: limite } },
        select: { id: true },
    });
    for (const g of velhos)
        await deleteGuest(prisma, g.id);
    return velhos.length;
}
export function inicioDoMes(d = new Date()): Date {
    return new Date(d.getFullYear(), d.getMonth(), 1);
}
