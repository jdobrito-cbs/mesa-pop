import type { PrismaClient } from '@prisma/client';
const SEGUNDOS_POR_FICHA = 300;
const acumulado = new Map<string, number>();
export async function creditarSegundos(prisma: PrismaClient, userIds: string[], segundos: number): Promise<void> {
    if (acumulado.size > 5000)
        acumulado.clear();
    for (const id of userIds) {
        const total = (acumulado.get(id) ?? 0) + segundos;
        const fichas = Math.floor(total / SEGUNDOS_POR_FICHA);
        acumulado.set(id, total - fichas * SEGUNDOS_POR_FICHA);
        if (fichas > 0) {
            await prisma.user.updateMany({ where: { id, isGuest: false }, data: { fichas: { increment: fichas } } });
        }
    }
}
export function zerarAcumulo(): void {
    acumulado.clear();
}
