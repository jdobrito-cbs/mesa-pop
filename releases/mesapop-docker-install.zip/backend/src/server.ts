import { buildApp } from './app';
import { config } from './config';
import { reapOldGuests } from './lib/guests';
import { abandonarPartidasOrfas, fecharSalasOrfas, reapSoloParadas } from './lib/matches';
import { creditarSegundos } from './lib/fichas';
import { liquidarApostas } from './lib/pareoApostas';
import { liquidarApostasCisco } from './lib/ciscoApostas';
const app = await buildApp();
await Promise.all([abandonarPartidasOrfas(app.prisma), fecharSalasOrfas(app.prisma)])
    .then(([m, s]) => (m || s) && app.log.info(`boot: ${m} partida(s) e ${s} sala(s) órfã(s) encerradas`))
    .catch((err) => app.log.warn({ err }, 'limpeza de órfãs no boot falhou'));
const guestReaper = setInterval(() => {
    reapOldGuests(app.prisma, 12).catch((err) => app.log.warn({ err }, 'reap de convidados falhou'));
}, 60 * 60 * 1000);
guestReaper.unref();
const matchReaper = setInterval(() => {
    reapSoloParadas(app.prisma, 30).catch((err) => app.log.warn({ err }, 'reap de partidas solo falhou'));
}, 10 * 60 * 1000);
matchReaper.unref();
const fichasSweep = setInterval(() => {
    const presentes = app.presence.list().filter((p) => !p.isGuest).map((p) => p.userId);
    creditarSegundos(app.prisma, presentes, 60).catch((err) => app.log.warn({ err }, 'credito de fichas falhou'));
}, 60 * 1000);
fichasSweep.unref();
const corridasSweep = setInterval(() => {
    liquidarApostas(app.prisma).catch((err) => app.log.warn({ err }, 'liquidação do Páreo falhou'));
    liquidarApostasCisco(app.prisma).catch((err) => app.log.warn({ err }, 'liquidação do Cisco falhou'));
}, 2500);
corridasSweep.unref();
try {
    await app.listen({ port: config.port, host: config.host });
}
catch (err) {
    app.log.error(err);
    process.exit(1);
}
