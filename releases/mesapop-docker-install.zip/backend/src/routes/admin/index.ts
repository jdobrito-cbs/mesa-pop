import type { FastifyInstance } from 'fastify';
import statsRoutes from './stats';
import usersRoutes from './users';
import auditRoutes from './audit';
import gamesAdminRoutes from './games';
import roomsAdminRoutes from './rooms';
import rankingsRoutes from './rankings';
import announcementsRoutes from './announcements';
import settingsAdminRoutes from './settings';
export default async function adminRoutes(app: FastifyInstance) {
    app.addHook('preHandler', app.requireAdmin);
    await app.register(statsRoutes);
    await app.register(usersRoutes);
    await app.register(auditRoutes);
    await app.register(gamesAdminRoutes);
    await app.register(roomsAdminRoutes);
    await app.register(rankingsRoutes);
    await app.register(announcementsRoutes);
    await app.register(settingsAdminRoutes);
}
