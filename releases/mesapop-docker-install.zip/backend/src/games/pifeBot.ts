import { melhorBatida, type PifeCard } from '@mesapop/shared';
import type { PifeState } from './pife';
import type { PifeAction } from '@mesapop/shared';
function contribuicao(cards: PifeCard[], i: number): number {
    const c = cards[i]!;
    let s = 0;
    for (let j = 0; j < cards.length; j++) {
        if (j === i)
            continue;
        const o = cards[j]!;
        if (o.r === c.r)
            s += 3;
        if (o.s === c.s) {
            const d = Math.abs(o.r - c.r);
            if (d === 1)
                s += 2;
            else if (d === 2)
                s += 1;
            const alta = (c.r === 1 && (o.r === 13 || o.r === 12)) || (o.r === 1 && (c.r === 13 || c.r === 12));
            if (alta)
                s += o.r === 13 || c.r === 13 ? 2 : 1;
        }
    }
    return s;
}
export function choosePifeAction(state: PifeState, seat: number): PifeAction | null {
    if (state.fase === 'fim')
        return null;
    if (state.turno !== seat)
        return null;
    const mao = state.maos[seat] ?? [];
    if (state.fase === 'comprando') {
        const topo = state.lixo[state.lixo.length - 1];
        if (topo) {
            const comTopo = [...mao, topo];
            if (contribuicao(comTopo, comTopo.length - 1) >= 3)
                return { type: 'lixo' };
            if (state.monte.length === 0 && state.lixo.length <= 1)
                return { type: 'lixo' };
        }
        return { type: 'monte' };
    }
    if (melhorBatida(mao, state.presaDoLixo))
        return { type: 'bater' };
    let worst = -1;
    let worstVal = Infinity;
    for (let i = 0; i < mao.length; i++) {
        if (i === state.presaDoLixo)
            continue;
        const v = contribuicao(mao, i);
        if (v < worstVal) {
            worstVal = v;
            worst = i;
        }
    }
    if (worst < 0)
        worst = state.presaDoLixo === 0 ? 1 : 0;
    return { type: 'descartar', index: worst };
}
