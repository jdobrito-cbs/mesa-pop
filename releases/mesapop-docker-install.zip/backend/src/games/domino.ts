import { applyDominoAction, dominoViewFor, initialDominoState, type DominoAction, type DominoState, } from '@mesapop/shared';
import type { GameModule } from './module';
import { chooseDominoAction } from './dominoBot';
export const dominoModule: GameModule<DominoState, DominoAction> = {
    slug: 'domino',
    minPlayers: 4,
    maxPlayers: 4,
    seatPicking: true,
    allowSpectators: true,
    rotation: true,
    init() {
        return initialDominoState();
    },
    play(state, seat, action) {
        if (!action || (action.type !== 'play' && action.type !== 'pass')) {
            return { error: 'Jogada inválida' };
        }
        return applyDominoAction(state, seat, action);
    },
    getStateFor(state, seat) {
        return dominoViewFor(state, seat);
    },
    currentSeat(state) {
        return state.winnerSeats.length || state.draw ? null : state.turn;
    },
    bot(state, seat) {
        return chooseDominoAction(state, seat);
    },
    result(state) {
        return {
            finished: state.winnerSeats.length > 0 || state.draw,
            winnerSeats: state.winnerSeats,
            draw: state.draw,
        };
    },
};
