import { canPlayCard, type OneAction, type OneCard, type OneColor, type OneState } from '@mesapop/shared';
const ACTIONS = ['skip', 'rev', '+2', '+4'];
function corPreferida(hand: OneCard[]): OneColor {
    const count: Record<OneColor, number> = { r: 0, y: 0, g: 0, b: 0 };
    for (const c of hand)
        if (c.c !== 'w')
            count[c.c]++;
    return (Object.keys(count) as OneColor[]).reduce((a, b) => (count[b] > count[a] ? b : a), 'r');
}
function rank(c: OneCard): number {
    let s = 0;
    if (ACTIONS.includes(c.v))
        s += 20;
    if (c.c === 'w')
        s -= 5;
    const n = Number(c.v);
    if (!Number.isNaN(n))
        s += n;
    return s;
}
export function chooseOneAction(state: OneState, seat: number): OneAction | null {
    if (state.winnerSeats.length)
        return null;
    if (state.turn !== seat)
        return null;
    const hand = state.hands[seat] ?? [];
    if (state.drawnPlayable) {
        const card = state.drawnPlayable;
        return card.c === 'w'
            ? { type: 'play', card, chooseColor: corPreferida(hand) }
            : { type: 'play', card };
    }
    const playable = hand.filter((c) => canPlayCard(state, c));
    if (playable.length === 0)
        return { type: 'draw' };
    const naoCuringa = playable.filter((c) => c.c !== 'w');
    const pool = naoCuringa.length ? naoCuringa : playable;
    let bestVal = -Infinity;
    let best: OneCard[] = [];
    for (const c of pool) {
        const v = rank(c);
        if (v > bestVal) {
            bestVal = v;
            best = [c];
        }
        else if (v === bestVal) {
            best.push(c);
        }
    }
    const pick = best[Math.floor(Math.random() * best.length)]!;
    return pick.c === 'w'
        ? { type: 'play', card: pick, chooseColor: corPreferida(hand) }
        : { type: 'play', card: pick };
}
