import crypto from 'node:crypto';
export type CorridaFase = 'apostas' | 'prelargada' | 'corrida' | 'cerimonia';
export interface CorridaState {
    numero: number;
    fase: CorridaFase;
    faseFimEm: number;
    largadaEm: number;
    seed: number;
    vencedor: number;
    winCrossT: number;
    historico: string[];
}
export interface CorridaConfig {
    apostasMs: number;
    prelargadaMs: number;
    corridaMs: number;
    cerimoniaMs: number;
    caudaMs: number;
    resultadoDe(seed: number): {
        vencedor: number;
        winCrossT: number;
    };
    nomeDe(lane: number): string;
}
function corridaMsDe(cfg: CorridaConfig, winCrossT: number): number {
    return Math.min(cfg.corridaMs, Math.round(winCrossT * cfg.corridaMs) + cfg.caudaMs);
}
export function novaCorrida(cfg: CorridaConfig, numero: number, historico: string[], agora = Date.now()): CorridaState {
    const seed = crypto.randomInt(1, 2147483646);
    const r = cfg.resultadoDe(seed);
    return {
        numero,
        fase: 'apostas',
        faseFimEm: agora + cfg.apostasMs,
        largadaEm: agora + cfg.apostasMs + cfg.prelargadaMs,
        seed,
        vencedor: r.vencedor,
        winCrossT: r.winCrossT,
        historico,
    };
}
export function avancaCicloCorrida(cfg: CorridaConfig, s: CorridaState, agora = Date.now()): void {
    while (agora >= s.faseFimEm) {
        if (s.fase === 'apostas') {
            s.fase = 'prelargada';
            s.faseFimEm = s.largadaEm;
        }
        else if (s.fase === 'prelargada') {
            s.fase = 'corrida';
            s.faseFimEm = s.largadaEm + corridaMsDe(cfg, s.winCrossT);
        }
        else if (s.fase === 'corrida') {
            s.fase = 'cerimonia';
            s.faseFimEm = s.largadaEm + cfg.corridaMs + cfg.cerimoniaMs;
            s.historico = [cfg.nomeDe(s.vencedor), ...s.historico].slice(0, 8);
        }
        else {
            const prox = novaCorrida(cfg, s.numero + 1, s.historico, s.faseFimEm);
            Object.assign(s, prox);
        }
    }
}
export function viewDeCorrida(s: CorridaState) {
    return {
        numero: s.numero,
        fase: s.fase,
        faseFimEm: s.faseFimEm,
        largadaEm: s.largadaEm,
        agora: Date.now(),
        seed: s.fase === 'corrida' || s.fase === 'cerimonia' ? s.seed : null,
        vencedor: s.fase === 'cerimonia' ? s.vencedor : null,
        historico: s.historico,
    };
}
