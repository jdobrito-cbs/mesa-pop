import { api, ApiRequestError } from './api';
export interface SoloFinish {
    points: number;
    rank?: number;
    best?: number;
    total?: number;
}
export interface SoloBackend {
    daily: boolean;
    nextSeed(): string;
    leaderboard: string;
    start(): Promise<string | null>;
    finish(token: string, points: number): Promise<SoloFinish | null>;
}
export function makeSoloBackend(slug: string, opts: {
    guest: boolean;
    daily?: string;
}): SoloBackend {
    const { guest, daily } = opts;
    if (daily) {
        return {
            daily: true,
            nextSeed: () => daily,
            leaderboard: `/api/desafio/ranking/${slug}`,
            async start() {
                if (guest)
                    return '';
                try {
                    await api('/api/desafio/start', { body: { gameSlug: slug } });
                    return 'daily';
                }
                catch (e) {
                    if (e instanceof ApiRequestError && e.status === 409)
                        return null;
                    return '';
                }
            },
            async finish(_token, points) {
                if (guest)
                    return null;
                try {
                    return await api<SoloFinish>('/api/desafio/finish', { body: { gameSlug: slug, points } });
                }
                catch {
                    return null;
                }
            },
        };
    }
    return {
        daily: false,
        nextSeed: () => `${Date.now()}-${Math.random()}`,
        leaderboard: `/api/leaderboards/${slug}`,
        async start() {
            if (guest)
                return '';
            try {
                const r = await api<{
                    matchId: string;
                }>('/api/solo/start', { body: { gameSlug: slug } });
                return r.matchId;
            }
            catch {
                return '';
            }
        },
        async finish(token, points) {
            if (!token)
                return null;
            try {
                return await api<SoloFinish>('/api/solo/finish', { body: { matchId: token, points } });
            }
            catch {
                return null;
            }
        },
    };
}
