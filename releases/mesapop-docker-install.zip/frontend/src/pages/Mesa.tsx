import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AVATARES_NORMAIS, GAME_CATALOG, type AnnouncementView, type GameDef, type GameView, type RankingsGerais, } from '@mesapop/shared';
import AdSlot from '../components/AdSlot';
import AvatarSvg from '../components/AvatarSvg';
import GameCard from '../components/GameCard';
import GumballModal from '../components/GumballModal';
import { api } from '../lib/api';
import { useAuth } from '../lib/auth';
import { useFetch } from '../lib/useFetch';
interface RoomRow {
    id: string;
    code: string;
    players: number;
    maxPlayers: number;
    playerNames: string[];
    isFavorite: boolean;
    game: {
        slug: string;
        name: string;
        icon: string;
        color: string;
    };
    host: {
        displayName: string;
    };
}
export function FavoriteStar({ room, onToggled, disabled, }: {
    room: {
        id: string;
        isFavorite: boolean;
    };
    onToggled: () => void;
    disabled?: boolean;
}) {
    if (disabled)
        return null;
    return (<button onClick={() => void api(`/api/rooms/${room.id}/favorite`, { method: 'POST' }).then(onToggled).catch(() => { })} aria-label={room.isFavorite ? 'Remover dos favoritos' : 'Favoritar sala'} title={room.isFavorite ? 'Remover dos favoritos' : 'Favoritar sala'} className={`btn-pop px-2 py-1 text-xl ${room.isFavorite ? 'text-pop-yellow' : 'text-text-muted/50 hover:text-pop-yellow'}`}>
      {room.isFavorite ? '★' : '☆'}
    </button>);
}
export function RoomPeople({ names, maxPlayers }: {
    names: string[];
    maxPlayers: number;
}) {
    const free = maxPlayers - names.length;
    return (<div className="mt-1.5 flex flex-wrap items-center gap-1.5">
      {names.map((n) => (<span key={n} className="flex items-center gap-1.5 rounded-full bg-ink-900 py-0.5 pr-2.5 pl-0.5 text-xs font-semibold ring-1 ring-ink-700">
          <AvatarSvg id={n} size={20}/>
          {n}
        </span>))}
      {free > 0 && (<span className="rounded-full border border-dashed border-ink-700 px-2.5 py-0.5 text-xs font-semibold text-text-muted">
          {free === 1 ? '1 lugar livre' : `${free} lugares livres`}
        </span>)}
    </div>);
}
const toGameDef = (g: GameView): GameDef => ({ ...g, enabled: g.isEnabled });
export default function Mesa() {
    const { user, setAvatar } = useAuth();
    const { data: gamesData, loading: loadingGames } = useFetch<{
        games: GameView[];
    }>('/api/games');
    const { data: roomsData, reload: reloadRooms } = useFetch<{
        rooms: RoomRow[];
    }>('/api/rooms');
    const { data: annData } = useFetch<{
        announcements: AnnouncementView[];
    }>('/api/announcements');
    const { data: geral } = useFetch<RankingsGerais>('/api/rankings/gerais');
    const { data: minha, reload: reloadMinha } = useFetch<{
        fichas: number;
        owned: string[];
        melhorPosicao: number | null;
    }>('/api/me/avatares');
    const [escolher, setEscolher] = useState(false);
    const [gumball, setGumball] = useState(false);
    useEffect(() => {
        if (user && !user.isGuest && !localStorage.getItem('mp_avatar_prompt'))
            setEscolher(true);
    }, [user]);
    function fecharPrompt(id?: string) {
        localStorage.setItem('mp_avatar_prompt', '1');
        void api('/api/me/avatar/prompt-visto', { method: 'POST' }).catch(() => { });
        if (id) {
            void api('/api/me/avatar', { method: 'PUT', body: { id } })
                .then(() => setAvatar(id))
                .catch(() => { });
        }
        setEscolher(false);
    }
    if (!user)
        return null;
    const firstName = user.displayName.split(' ')[0];
    const enabled = gamesData?.games ?? [];
    const enabledSlugs = new Set(enabled.map((g) => g.slug));
    const comingSoon = GAME_CATALOG.filter((g) => !enabledSlugs.has(g.slug)).slice(0, 6);
    return (<main className="mx-auto max-w-6xl px-4 py-12">
      <h1 className="text-4xl font-extrabold">
        E aí, <span className="text-pop-cyan">{firstName}</span>! 👋
      </h1>

      
      {user.isGuest && (<div className="card mt-6 flex flex-wrap items-center justify-between gap-3 border-l-4 border-l-pop-cyan p-4">
          <p className="text-sm text-text-muted">
            🎟️ Você está jogando como <strong className="text-text">convidado</strong> — chat,
            fazenda, favoritos e ranking pedem conta.
          </p>
          <Link to="/criar-conta" className="btn-pop bg-gradient-to-br from-pop-purple to-pop-magenta px-5 py-2.5 text-sm text-white">
            Criar minha conta
          </Link>
        </div>)}

      
      {!user.isGuest && (<div className="mt-6 grid gap-3 sm:grid-cols-2">
          <Link to="/rankings" className="card group relative overflow-hidden border-0 bg-gradient-to-br from-pop-purple to-pop-magenta p-4 text-white transition hover:-translate-y-0.5">
            <p className="text-xs font-bold tracking-widest uppercase opacity-80">🏆 Ranking geral · pontos</p>
            <p className="mt-1 font-display text-lg font-extrabold">
              {geral?.voce?.pontos ? (<>
                  {user.displayName}, você é o <span className="text-pop-yellow">nº {geral.voce.pontos}</span>!
                </>) : ('Some pontos em qualquer jogo e apareça aqui!')}
            </p>
            <p className="mt-0.5 text-xs opacity-80">Top 10 usa avatares especiais ✨ — toque para ver</p>
          </Link>
          <Link to="/rankings" className="card group relative overflow-hidden border-0 bg-gradient-to-br from-pop-cyan to-pop-purple p-4 text-white transition hover:-translate-y-0.5">
            <p className="text-xs font-bold tracking-widest uppercase opacity-80">⏱️ Ranking geral · tempo de jogo</p>
            <p className="mt-1 font-display text-lg font-extrabold">
              {geral?.voce?.tempo ? (<>
                  {user.displayName}, você é o <span className="text-pop-yellow">nº {geral.voce.tempo}</span>!
                </>) : ('Jogue mais para entrar no ranking!')}
            </p>
            <p className="mt-0.5 text-xs opacity-80">O nº 1 usa os avatares SUPER 👑 — toque para ver</p>
          </Link>
        </div>)}

      
      {!user.isGuest && (<div className="card mt-3 flex flex-wrap items-center justify-between gap-3 border-l-4 border-l-pop-yellow p-4">
          <div>
            <p className="font-display font-bold">🪙 Suas fichas: <span className="text-pop-yellow tabular-nums">{(minha?.fichas ?? user.fichas).toLocaleString('pt-BR')}</span></p>
            <p className="text-sm text-text-muted">Você ganha 1 ficha a cada 5 minutos jogando · 1.000 fichas = 1 avatar especial</p>
          </div>
          <button onClick={() => setGumball(true)} className="btn-pop bg-gradient-to-br from-pop-yellow to-pop-orange px-5 py-2.5 text-sm font-bold text-ink-950">
            🎰 Trocar por avatar
          </button>
        </div>)}

      
      {!!annData?.announcements.length && (<div className="mt-6 flex flex-col gap-3">
          {annData.announcements.map((a) => (<div key={a.id} className="card flex items-start gap-3 border-l-4 border-l-pop-yellow p-4">
              <span className="text-2xl" aria-hidden="true">📣</span>
              <div>
                <p className="font-display font-bold">{a.title}</p>
                <p className="text-sm text-text-muted">{a.message}</p>
              </div>
            </div>))}
        </div>)}

      
      <Link to="/desafio" className="card mt-6 flex items-center gap-4 border-l-4 border-l-pop-yellow p-5 transition hover:-translate-y-0.5 hover:ring-pop-yellow/50">
        <span className="text-3xl" aria-hidden="true">📅</span>
        <div className="min-w-0 flex-1">
          <p className="font-display text-lg font-bold">Desafio Diário</p>
          <p className="text-sm text-text-muted">
            Sudoku, Caça-palavras, Cruzadinha e Mahjong — o mesmo tabuleiro para toda a mesa hoje. Ranking do dia!
          </p>
        </div>
        <span className="hidden shrink-0 rounded-full px-3 py-1 text-sm font-bold text-pop-yellow ring-1 ring-pop-yellow/40 sm:block">
          Jogar →
        </span>
      </Link>

      
      <h2 className="mt-10 text-2xl font-extrabold">Na mesa agora</h2>
      {loadingGames && <p className="mt-3 text-text-muted">Preparando a mesa…</p>}
      {!loadingGames && enabled.length === 0 && (<div className="card mt-4 p-8 text-center">
          <p className="text-4xl" aria-hidden="true">🎲</p>
          <p className="mt-3 font-display text-lg font-bold">A mesa está sendo montada</p>
          <p className="mt-1 text-sm text-text-muted">
            Os primeiros jogos acendem aqui em breve — um a um, começando pelas Damas.
          </p>
        </div>)}
      {enabled.length > 0 && (<div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {enabled.map((g) => (<GameCard key={g.slug} game={toGameDef(g)}/>))}
        </div>)}

      
      <h2 className="mt-10 text-2xl font-extrabold">Salas abertas</h2>
      {!roomsData?.rooms.length ? (<p className="mt-3 text-sm text-text-muted">
          Nenhuma sala pública esperando jogadores agora. Quando os jogos multiplayer
          chegarem, é aqui que você encontra gente para jogar.
        </p>) : (<div className="mt-4 grid gap-3 sm:grid-cols-2">
          {roomsData.rooms.map((r) => (<div key={r.id} className="card flex items-start gap-3 p-4">
              <span className="text-3xl" aria-hidden="true">{r.game.icon}</span>
              <div className="min-w-0 flex-1">
                <p className="font-display font-bold">{r.game.name}</p>
                <p className="text-sm text-text-muted">
                  Mesa de {r.host.displayName} · {r.players}/{r.maxPlayers} jogadores
                </p>
                <RoomPeople names={r.playerNames} maxPlayers={r.maxPlayers}/>
              </div>
              <FavoriteStar room={r} onToggled={() => void reloadRooms()} disabled={user.isGuest}/>
              <span className="font-mono text-sm font-bold text-pop-cyan">{r.code}</span>
            </div>))}
        </div>)}

      <AdSlot className="mt-10"/>

      
      {comingSoon.length > 0 && (<>
          <h2 className="mt-10 text-2xl font-extrabold">Chegando na mesa</h2>
          <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {comingSoon.map((game) => (<GameCard key={game.slug} game={game}/>))}
          </div>
        </>)}

      
      {escolher && (<div className="fixed inset-0 z-[80] grid place-items-center bg-ink-950/80 p-4" onClick={() => fecharPrompt()}>
          <div className="card w-full max-w-2xl p-5" onClick={(e) => e.stopPropagation()}>
            <h2 className="font-display text-xl font-extrabold">Escolha seu avatar 🎭</h2>
            <p className="mb-3 text-sm text-text-muted">Dá para trocar quando quiser em "Meus avatares".</p>
            <div className="grid grid-cols-5 gap-2 sm:grid-cols-10">
              {AVATARES_NORMAIS.map((id) => (<button key={id} onClick={() => fecharPrompt(id)} className="rounded-full ring-2 ring-transparent transition hover:ring-pop-cyan">
                  <AvatarSvg id={id} size={44}/>
                </button>))}
            </div>
            <button onClick={() => fecharPrompt()} className="btn-pop mt-4 px-4 py-2 text-sm ring-1 ring-ink-700">Agora não</button>
          </div>
        </div>)}

      {gumball && (<GumballModal fichas={minha?.fichas ?? user.fichas} onFichas={() => void reloadMinha()} onClose={() => setGumball(false)}/>)}
    </main>);
}
