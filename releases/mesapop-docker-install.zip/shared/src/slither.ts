export const COBRA_RAIO = 1150;
export const COBRA_DURACAO = 150;
export const COBRA_SEG = 8;
export interface CobraSnakeView {
    id: string;
    seat: number | null;
    nome: string;
    cor: string;
    vivo: boolean;
    boost: boolean;
    corpo: Array<{
        x: number;
        y: number;
    }>;
    raio: number;
    tamanho: number;
}
export interface CobraFoodView {
    x: number;
    y: number;
    r: number;
    c: string;
}
export interface CobraPlacar {
    seat: number | null;
    nome: string;
    tamanho: number;
    vivo: boolean;
}
export interface CobraSnapshot {
    raio: number;
    tempo: number;
    duracao: number;
    snakes: CobraSnakeView[];
    food: CobraFoodView[];
    placar: CobraPlacar[];
    finished: boolean;
    winnerSeats: number[];
    draw: boolean;
}
export type CobraAction = {
    type: 'mira';
    angulo: number;
} | {
    type: 'boost';
    on: boolean;
};
