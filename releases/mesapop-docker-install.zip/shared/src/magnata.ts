export type MagnataGrupo = 'marrom' | 'azulc' | 'rosa' | 'laranja' | 'vermelho' | 'amarelo' | 'verde' | 'azul' | 'estacao' | 'servico';
export type MagnataTipo = 'inicio' | 'propriedade' | 'estacao' | 'servico' | 'sorte' | 'cofre' | 'imposto' | 'prisao' | 'vaprisao' | 'parada';
export interface MagnataCasa {
    i: number;
    tipo: MagnataTipo;
    nome: string;
    grupo?: MagnataGrupo;
    preco?: number;
    imposto?: number;
}
export const CORES_GRUPO: Record<MagnataGrupo, string> = {
    marrom: '#8a5a2b',
    azulc: '#7fd3ef',
    rosa: '#e75a9c',
    laranja: '#f08a24',
    vermelho: '#e03131',
    amarelo: '#f4d03f',
    verde: '#2f9e44',
    azul: '#1f6feb',
    estacao: '#5a6270',
    servico: '#9aa3af',
};
const P = (i: number, nome: string, grupo: MagnataGrupo, preco: number): MagnataCasa => ({ i, tipo: 'propriedade', nome, grupo, preco });
export const MAGNATA_CASAS: MagnataCasa[] = [
    { i: 0, tipo: 'inicio', nome: 'Início' },
    P(1, 'Rua da Praia', 'marrom', 60),
    { i: 2, tipo: 'cofre', nome: 'Cofre' },
    P(3, 'Ladeira da Misericórdia', 'marrom', 60),
    { i: 4, tipo: 'imposto', nome: 'Imposto de Renda', imposto: 200 },
    { i: 5, tipo: 'estacao', nome: 'Aeroporto de Guarulhos', grupo: 'estacao', preco: 200 },
    P(6, 'Rua XV de Novembro', 'azulc', 100),
    { i: 7, tipo: 'sorte', nome: 'Sorte' },
    P(8, 'Av. Sete de Setembro', 'azulc', 100),
    P(9, 'Rua das Flores', 'azulc', 120),
    { i: 10, tipo: 'prisao', nome: 'Prisão' },
    P(11, 'Av. Boa Viagem', 'rosa', 140),
    { i: 12, tipo: 'servico', nome: 'Companhia de Luz', grupo: 'servico', preco: 150 },
    P(13, 'Rua Oscar Freire', 'rosa', 140),
    P(14, 'Praia de Iracema', 'rosa', 160),
    { i: 15, tipo: 'estacao', nome: 'Aeroporto do Galeão', grupo: 'estacao', preco: 200 },
    P(16, 'Av. Atlântica', 'laranja', 180),
    { i: 17, tipo: 'cofre', nome: 'Cofre' },
    P(18, 'Rua 25 de Março', 'laranja', 180),
    P(19, 'Av. Afonso Pena', 'laranja', 200),
    { i: 20, tipo: 'parada', nome: 'Parada Livre' },
    P(21, 'Av. Beira-Mar', 'vermelho', 220),
    { i: 22, tipo: 'sorte', nome: 'Sorte' },
    P(23, 'Praia da Costa', 'vermelho', 220),
    P(24, 'Av. Goethe', 'vermelho', 240),
    { i: 25, tipo: 'estacao', nome: 'Aeroporto de Brasília', grupo: 'estacao', preco: 200 },
    P(26, 'Av. Brasil', 'amarelo', 260),
    P(27, 'Orla de Atalaia', 'amarelo', 260),
    { i: 28, tipo: 'servico', nome: 'Companhia de Água', grupo: 'servico', preco: 150 },
    P(29, 'Av. N. S. de Copacabana', 'amarelo', 280),
    { i: 30, tipo: 'vaprisao', nome: 'Vá para a Prisão' },
    P(31, 'Av. Faria Lima', 'verde', 300),
    P(32, 'Praia de Jericoacoara', 'verde', 300),
    { i: 33, tipo: 'cofre', nome: 'Cofre' },
    P(34, 'Av. das Nações', 'verde', 320),
    { i: 35, tipo: 'estacao', nome: 'Aeroporto de Confins', grupo: 'estacao', preco: 200 },
    { i: 36, tipo: 'sorte', nome: 'Sorte' },
    P(37, 'Av. Paulista', 'azul', 350),
    { i: 38, tipo: 'imposto', nome: 'Imposto de Luxo', imposto: 100 },
    P(39, 'Praia de Copacabana', 'azul', 400),
];
export const MAGNATA_CORES = ['#ff3ea5', '#22d3ee', '#facc15', '#34d399', '#a855f7', '#fb923c', '#ef4444', '#3b82f6'];
export const MAGNATA_INICIO_BONUS = 200;
export const MAGNATA_FIANCA = 50;
export const MAGNATA_DINHEIRO_INICIAL = 1500;
export const MAGNATA_CARTAO_INICIAL = 500;
export const CUSTO_CASA: Record<string, number> = {
    marrom: 50, azulc: 50, rosa: 100, laranja: 100, vermelho: 150, amarelo: 150, verde: 200, azul: 200,
};
export function grupoDe(grupo: MagnataGrupo): number[] {
    return MAGNATA_CASAS.filter((c) => c.grupo === grupo && c.tipo === 'propriedade').map((c) => c.i);
}
export function aluguelPropriedade(preco: number, casas: number, monopolio: boolean): number {
    const base = Math.max(4, Math.round(preco * 0.09));
    if (casas <= 0)
        return monopolio ? base * 2 : base;
    const mult = [0, 5, 14, 40, 55, 70][Math.min(casas, 5)]!;
    return base * mult;
}
export function aluguelEstacao(qtd: number): number {
    return [0, 25, 50, 100, 200][Math.min(qtd, 4)]!;
}
export function aluguelServico(dados: number, ambos: boolean): number {
    return dados * (ambos ? 10 : 4);
}
export function valorHipoteca(preco: number): number {
    return Math.round(preco / 2);
}
export function custoResgate(preco: number): number {
    return Math.round(valorHipoteca(preco) * 1.1);
}
export interface MagnataJogador {
    seat: number;
    nome: string;
    cor: string;
    pos: number;
    dinheiro: number;
    cartaoLimite: number;
    cartaoUsado: number;
    props: number[];
    casas: Record<number, number>;
    hipotecadas: number[];
    preso: boolean;
    turnosPreso: number;
    falido: boolean;
    isBot?: boolean;
    jaRolou: boolean;
}
export type MagnataFase = 'rolar' | 'comprar' | 'agir' | 'leilao' | 'fim';
export interface MagnataLeilao {
    casa: number;
    lance: number;
    lider: number | null;
    ativos: number[];
    vez: number;
}
export interface MagnataProposta {
    de: number;
    para: number;
    ofereceProps: number[];
    ofereceDinheiro: number;
    pedeProps: number[];
    pedeDinheiro: number;
}
export interface MagnataView {
    jogadores: MagnataJogador[];
    turno: number;
    fase: MagnataFase;
    dados: [
        number,
        number
    ] | null;
    rolagens: number;
    donoDe: Array<number | null>;
    log: string[];
    aviso: string | null;
    compravel: number | null;
    leilao: MagnataLeilao | null;
    proposta: MagnataProposta | null;
    winnerSeats: number[];
    vencedor: number | null;
}
export type MagnataAction = {
    type: 'rolar';
} | {
    type: 'comprar';
} | {
    type: 'passar';
} | {
    type: 'construir';
    casa: number;
} | {
    type: 'venderCasa';
    casa: number;
} | {
    type: 'hipotecar';
    casa: number;
} | {
    type: 'resgatar';
    casa: number;
} | {
    type: 'fianca';
} | {
    type: 'encerrar';
} | {
    type: 'lance';
    valor: number;
} | {
    type: 'desistir';
} | {
    type: 'propor';
    para: number;
    ofereceProps: number[];
    ofereceDinheiro: number;
    pedeProps: number[];
    pedeDinheiro: number;
} | {
    type: 'aceitarTroca';
} | {
    type: 'recusarTroca';
} | {
    type: 'cor';
    cor: string;
};
