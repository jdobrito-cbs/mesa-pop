export type TrucoNaipe = 'o' | 'e' | 'c' | 'p';
export type TrucoRank = '4' | '5' | '6' | '7' | 'Q' | 'J' | 'K' | 'A' | '2' | '3';
export interface TrucoCard {
    r: TrucoRank;
    s: TrucoNaipe;
}
export const TRUCO_ORDEM: TrucoRank[] = ['4', '5', '6', '7', 'Q', 'J', 'K', 'A', '2', '3'];
export const TRUCO_NAIPES: TrucoNaipe[] = ['o', 'e', 'c', 'p'];
export function manilhaRank(vira: TrucoCard): TrucoRank {
    const i = TRUCO_ORDEM.indexOf(vira.r);
    return TRUCO_ORDEM[(i + 1) % TRUCO_ORDEM.length]!;
}
export function forcaCarta(card: TrucoCard, vira: TrucoCard): number {
    if (card.r === manilhaRank(vira))
        return 100 + TRUCO_NAIPES.indexOf(card.s);
    return TRUCO_ORDEM.indexOf(card.r);
}
export interface TrucoMesaCarta {
    seat: number;
    card: TrucoCard;
}
export type TrucoFase = 'jogando' | 'respondendo' | 'fim';
export interface TrucoView {
    fase: TrucoFase;
    players: number;
    minhaMao: TrucoCard[];
    cartasRestantes: number[];
    mesa: TrucoMesaCarta[];
    vira: TrucoCard;
    manilha: TrucoRank;
    turno: number;
    valor: number;
    pendente: {
        paraTeam: number;
        novoValor: number;
        pedidoPor: number;
    } | null;
    vazas: Array<number | null>;
    placar: [
        number,
        number
    ];
    ultimaMao: {
        team: number | null;
        valor: number;
        correu: boolean;
    } | null;
    vencedores: number[];
    meuTeam: number;
}
export const teamOf = (seat: number) => seat % 2;
export function vencedorVaza(mesa: TrucoMesaCarta[], vira: TrucoCard): number | null {
    let melhor = -1;
    let melhorSeat = -1;
    let empate = false;
    for (const jogada of mesa) {
        const f = forcaCarta(jogada.card, vira);
        if (f > melhor) {
            melhor = f;
            melhorSeat = jogada.seat;
            empate = false;
        }
        else if (f === melhor && teamOf(jogada.seat) !== teamOf(melhorSeat)) {
            empate = true;
        }
    }
    return empate ? null : teamOf(melhorSeat);
}
export function vencedorMao(vazas: Array<number | null>): number | null | undefined {
    const wins = [0, 0];
    for (const v of vazas) {
        if (v !== null)
            wins[v]!++;
    }
    if (wins[0]! >= 2)
        return 0;
    if (wins[1]! >= 2)
        return 1;
    if (vazas.includes(null)) {
        const primeira = vazas.find((v) => v !== null);
        if (primeira !== undefined && primeira !== null)
            return primeira;
        if (vazas.length >= 3)
            return null;
    }
    if (vazas.length >= 3) {
        if (wins[0]! > wins[1]!)
            return 0;
        if (wins[1]! > wins[0]!)
            return 1;
        return null;
    }
    return undefined;
}
