export interface PareoCavaloDef {
    nome: string;
    cor: string;
    peso: number;
}
export const PAREO_CAVALOS: PareoCavaloDef[] = [
    { nome: 'Trovão', cor: '#e0563f', peso: 0.34 },
    { nome: 'Relâmpago', cor: '#4aa3df', peso: 0.28 },
    { nome: 'Aurora', cor: '#e8c34a', peso: 0.22 },
    { nome: 'Corcel', cor: '#8d7ae0', peso: 0.16 },
];
export const PAREO_HOUSE_EDGE = 0.88;
export const PAREO_APOSTAS_FICHAS = [10, 25, 50, 100, 250];
export const PAREO_APOSTAS_MS = 123000;
export const PAREO_PRELARGADA_MS = 30000;
export const PAREO_CORRIDA_MS = 20000;
export const PAREO_CERIMONIA_MS = 7000;
export const PAREO_CAUDA_MS = 1100;
export type PareoFase = 'apostas' | 'prelargada' | 'corrida' | 'cerimonia';
export function pareoOdds(): number[] {
    const total = PAREO_CAVALOS.reduce((s, h) => s + h.peso, 0);
    return PAREO_CAVALOS.map((h) => Math.round(Math.max(1.2, (1 / (h.peso / total)) * PAREO_HOUSE_EDGE) * 10) / 10);
}
export const PAREO_ODDS = pareoOdds();
export const PAREO_TRACK_LEN = 9400;
export const PAREO_FINISH = 8580;
export const PAREO_SIM_STEPS = 600;
const SIM_DT = PAREO_CORRIDA_MS / 1000 / PAREO_SIM_STEPS;
export function pareoRandom(seed: number): () => number {
    let s = seed % 2147483647;
    if (s <= 0)
        s += 2147483646;
    return () => (s = (s * 16807) % 2147483647) / 2147483647;
}
interface FaseOrganica {
    amp: number;
    freq: number;
    off: number;
}
export interface PareoCavalo extends PareoCavaloDef {
    lane: number;
    odds: number;
    skill: number;
    formOfDay: number;
    fases: FaseOrganica[];
    traj: Float32Array;
    legTraj: Float32Array;
}
export interface PareoCorrida {
    seed: number;
    vencedor: number;
    ordem: number[];
    cavalos: PareoCavalo[];
    winCrossT: number;
}
export function pareoOrganicSpeed(c: PareoCavalo, t: number): number {
    let s = c.skill * c.formOfDay;
    for (const p of c.fases)
        s += p.amp * Math.sin(p.freq * t * Math.PI * 2 + p.off);
    s += 0.06 * Math.sin(t * Math.PI) + 0.08 * Math.pow(t, 3);
    return Math.max(0.35, s);
}
export function pareoBuildRace(seed: number): PareoCorrida {
    const rng = pareoRandom((seed * 2654435761) >>> 0);
    const totalW = PAREO_CAVALOS.reduce((s, h) => s + h.peso, 0);
    const cavalos: PareoCavalo[] = PAREO_CAVALOS.map((def, i) => {
        const fases: FaseOrganica[] = [];
        for (let k = 0; k < 4; k++) {
            fases.push({ amp: 0.1 + rng() * 0.16, freq: 0.7 + rng() * 2.0, off: rng() * Math.PI * 2 });
        }
        const prob = def.peso / totalW;
        return {
            ...def,
            lane: i,
            fases,
            skill: 0.94 + prob * 0.28,
            formOfDay: 0.95 + rng() * 0.1,
            odds: PAREO_ODDS[i]!,
            traj: new Float32Array(PAREO_SIM_STEPS + 1),
            legTraj: new Float32Array(PAREO_SIM_STEPS + 1),
        };
    });
    let vencedor: number | null = null;
    const ordem: number[] = [];
    const x = cavalos.map(() => 0);
    const legAcc = cavalos.map(() => 0);
    const crossStep = cavalos.map<number | null>(() => null);
    for (let s = 0; s <= PAREO_SIM_STEPS; s++) {
        const t = s / PAREO_SIM_STEPS;
        cavalos.forEach((c, i) => {
            c.traj[s] = x[i]!;
            c.legTraj[s] = legAcc[i]!;
        });
        const cruzaram: Array<{
            i: number;
            cross: number;
        }> = [];
        cavalos.forEach((_, i) => {
            if (crossStep[i] === null && x[i]! >= PAREO_FINISH) {
                const prev = s > 0 ? cavalos[i]!.traj[s - 1]! : 0;
                const frac = x[i]! - prev > 0 ? (PAREO_FINISH - prev) / (x[i]! - prev) : 0;
                cruzaram.push({ i, cross: s - 1 + frac });
            }
        });
        if (cruzaram.length) {
            cruzaram.sort((a, b) => a.cross - b.cross);
            cruzaram.forEach(({ i }) => {
                crossStep[i] = s;
                ordem.push(i);
                if (vencedor === null)
                    vencedor = i;
            });
        }
        cavalos.forEach((c, i) => {
            const sp = pareoOrganicSpeed(c, t);
            x[i]! += sp * (PAREO_TRACK_LEN / (PAREO_CORRIDA_MS / 1000)) * SIM_DT;
            legAcc[i]! += sp * SIM_DT * 12;
        });
    }
    if (vencedor === null) {
        let best = 0;
        for (let i = 1; i < cavalos.length; i++)
            if (x[i]! > x[best]!)
                best = i;
        vencedor = best;
    }
    cavalos
        .map((_, i) => i)
        .sort((a, b) => x[b]! - x[a]!)
        .forEach((i) => {
        if (!ordem.includes(i))
            ordem.push(i);
    });
    const w = cavalos[vencedor]!;
    let winCrossT = 1;
    for (let s = 0; s <= PAREO_SIM_STEPS; s++) {
        if (w.traj[s]! >= PAREO_FINISH) {
            const prev = s > 0 ? w.traj[s - 1]! : 0;
            const frac = w.traj[s]! - prev > 0 ? (PAREO_FINISH - prev) / (w.traj[s]! - prev) : 0;
            winCrossT = (s - 1 + frac) / PAREO_SIM_STEPS;
            break;
        }
    }
    return { seed, vencedor, ordem, cavalos, winCrossT };
}
export function pareoHorseAt(c: PareoCavalo, t: number): {
    x: number;
    legT: number;
} {
    const f = Math.max(0, Math.min(1, t)) * PAREO_SIM_STEPS;
    const i = Math.floor(f);
    const frac = f - i;
    const a = c.traj[i]!;
    const b = c.traj[Math.min(PAREO_SIM_STEPS, i + 1)]!;
    const la = c.legTraj[i]!;
    const lb = c.legTraj[Math.min(PAREO_SIM_STEPS, i + 1)]!;
    return { x: a + (b - a) * frac, legT: la + (lb - la) * frac };
}
export interface PareoView {
    numero: number;
    fase: PareoFase;
    faseFimEm: number;
    largadaEm: number;
    agora: number;
    seed: number | null;
    vencedor: number | null;
    historico: string[];
}
