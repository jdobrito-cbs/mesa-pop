export const GANSO_FIM = 63;
const GANSOS = new Set([5, 9, 14, 18, 23, 27, 32, 36, 41, 45, 50, 54, 59]);
export type GansoEvento = 'ricochete' | 'ganso' | 'ponte' | 'estalagem' | 'poco' | 'labirinto' | 'caveira' | 'chegou';
export type CasaTipo = 'normal' | 'ganso' | 'ponte' | 'estalagem' | 'poco' | 'labirinto' | 'caveira' | 'fim';
export interface CasaInfo {
    tipo: CasaTipo;
    destino?: number;
}
export function casaInfo(pos: number): CasaInfo {
    if (pos === GANSO_FIM)
        return { tipo: 'fim' };
    if (pos === 6)
        return { tipo: 'ponte', destino: 12 };
    if (pos === 19)
        return { tipo: 'estalagem' };
    if (pos === 31)
        return { tipo: 'poco' };
    if (pos === 42)
        return { tipo: 'labirinto', destino: 30 };
    if (pos === 58)
        return { tipo: 'caveira', destino: 0 };
    if (GANSOS.has(pos))
        return { tipo: 'ganso' };
    return { tipo: 'normal' };
}
export interface GansoState {
    players: number;
    positions: number[];
    skip: number[];
    turn: number;
    lastRoll: [
        number,
        number
    ] | null;
    lastMove: {
        seat: number;
        from: number;
        to: number;
        roll: number;
        eventos: GansoEvento[];
    } | null;
    winner: number | null;
}
export function initialGansoState(players: number): GansoState {
    return {
        players,
        positions: Array(players).fill(0),
        skip: Array(players).fill(0),
        turn: 0,
        lastRoll: null,
        lastMove: null,
        winner: null,
    };
}
function resolveDestino(from: number, roll: number): {
    to: number;
    eventos: GansoEvento[];
    skip: number;
} {
    const eventos: GansoEvento[] = [];
    let pos = from + roll;
    let skip = 0;
    for (let i = 0; i < 24; i++) {
        if (pos > GANSO_FIM) {
            pos = GANSO_FIM - (pos - GANSO_FIM);
            eventos.push('ricochete');
        }
        const info = casaInfo(pos);
        if (info.tipo === 'ganso') {
            eventos.push('ganso');
            pos += roll;
            continue;
        }
        if (info.tipo === 'ponte') {
            eventos.push('ponte');
            pos = info.destino!;
            break;
        }
        if (info.tipo === 'labirinto') {
            eventos.push('labirinto');
            pos = info.destino!;
            break;
        }
        if (info.tipo === 'caveira') {
            eventos.push('caveira');
            pos = info.destino!;
            break;
        }
        if (info.tipo === 'estalagem') {
            eventos.push('estalagem');
            skip = 1;
            break;
        }
        if (info.tipo === 'poco') {
            eventos.push('poco');
            skip = 2;
            break;
        }
        break;
    }
    if (pos === GANSO_FIM)
        eventos.push('chegou');
    return { to: pos, eventos, skip };
}
function proximoTurno(positions: number[], skip: number[], atual: number, players: number): number {
    let t = atual;
    for (let i = 0; i < players * 3; i++) {
        t = (t + 1) % players;
        if (skip[t]! > 0) {
            skip[t]! -= 1;
            continue;
        }
        return t;
    }
    return (atual + 1) % players;
}
export function aplicaRolagem(state: GansoState, seat: number, dados: [
    number,
    number
]): {
    error: string;
} | {
    state: GansoState;
} {
    if (state.winner !== null)
        return { error: 'A partida já terminou' };
    if (state.turn !== seat)
        return { error: 'Não é a sua vez' };
    const [d1, d2] = dados;
    if (![1, 2, 3, 4, 5, 6].includes(d1) || ![1, 2, 3, 4, 5, 6].includes(d2)) {
        return { error: 'Dados inválidos' };
    }
    const roll = d1 + d2;
    const from = state.positions[seat]!;
    const { to, eventos, skip } = resolveDestino(from, roll);
    const positions = state.positions.slice();
    positions[seat] = to;
    const skips = state.skip.slice();
    skips[seat] = skip;
    const winner = to === GANSO_FIM ? seat : null;
    const turn = winner !== null ? state.turn : proximoTurno(positions, skips, seat, state.players);
    return {
        state: {
            ...state,
            positions,
            skip: skips,
            turn,
            lastRoll: [d1, d2],
            lastMove: { seat, from, to, roll, eventos },
            winner,
        },
    };
}
