export interface DesenhaStroke {
    color: string;
    size: number;
    pts: number[];
}
export interface RespostaEntry {
    seat: number;
    text: string | null;
    acertou: boolean;
}
export type DesenhaFase = 'escolhendo' | 'desenhando' | 'revelacao' | 'fim';
export interface DesenhaView {
    fase: DesenhaFase;
    rodada: number;
    totalRodadas: number;
    desenhistaSeat: number;
    tempo: number;
    dica: string | null;
    palavra: string | null;
    strokes: DesenhaStroke[];
    scores: number[];
    acertaram: number[];
    respostas: RespostaEntry[];
    vencedores: number[];
}
export const DESENHA_TEMPO_ESCOLHA = 45;
export const DESENHA_TEMPO_RODADA = 180;
export const DESENHA_TEMPO_REVELACAO = 5;
export const DESENHA_RODADAS_POR_JOGADOR = 2;
export function normalizaPalavra(s: string): string {
    return s
        .toLowerCase()
        .normalize('NFD')
        .replace(/[̀-ͯ]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}
export function dicaDe(palavra: string, reveladas: number): string {
    const chars = [...palavra];
    const letras = chars.map((c, i) => ({ c, i })).filter(({ c }) => c !== ' ');
    const mostrar = new Set<number>();
    for (let k = 0; k < Math.min(reveladas, Math.floor(letras.length / 3)); k++) {
        const idx = letras[Math.floor(((k + 1) * letras.length) / (reveladas + 1))]?.i;
        if (idx !== undefined)
            mostrar.add(idx);
    }
    return chars.map((c, i) => (c === ' ' ? ' ' : mostrar.has(i) ? c : '_')).join(' ');
}
