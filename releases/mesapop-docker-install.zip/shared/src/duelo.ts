export interface DueloTentativa {
    palpite: string;
    feedback: string;
}
export interface DueloRivalView {
    seat: number;
    feedbacks: string[];
    acabou: boolean;
    acertou: boolean;
}
export interface DueloView {
    fase: 'jogando' | 'fim';
    tempo: number;
    minha: DueloTentativa[];
    acabei: boolean;
    acertei: boolean;
    rivais: DueloRivalView[];
    vencedores: number[];
    palavra: string | null;
    maxTentativas: number;
}
export const DUELO_TEMPO = 240;
export const DUELO_TENTATIVAS = 6;
