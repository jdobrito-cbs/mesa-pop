export const MILHAO_ESCADA = [
    1000, 2000, 5000, 10000, 20000, 30000, 40000, 50000,
    100000, 150000, 200000, 250000, 300000, 400000, 500000, 1000000,
] as const;
export const MILHAO_NIVEIS = MILHAO_ESCADA.length;
export const MILHAO_PULOS = 3;
export type MilhaoAjuda = 'cartas' | 'universitarios' | 'plateia' | 'pulo';
export type MilhaoResultado = 'parou' | 'errou' | 'milhao';
export interface MilhaoUniversitario {
    nome: string;
    palpite: number;
    confianca: number;
}
export interface MilhaoView {
    fase: 'pergunta' | 'fim';
    nivel: number;
    valorPergunta: number;
    acumulado: number;
    seErrar: number;
    pergunta: {
        categoria: string;
        texto: string;
        alternativas: string[];
    } | null;
    eliminadas: number[];
    ajudasUsadas: Exclude<MilhaoAjuda, 'pulo'>[];
    pulosRestantes: number;
    universitarios: MilhaoUniversitario[] | null;
    plateia: number[] | null;
    ultima: {
        escolha: number;
        correta: number;
        certo: boolean;
    } | null;
    resultado: MilhaoResultado | null;
    premio: number;
    pontosGanhos: number;
    fichasGanhas: number;
}
export const MILHAO_PONTOS_MAX = 50000;
export const MILHAO_FICHAS_MAX = 100;
export function milhaoPontos(premio: number): number {
    return Math.floor(premio / 20);
}
export function milhaoFichas(premio: number): number {
    return Math.floor(premio / 10000);
}
export function milhaoSeErrar(nivel: number, acumulado: number): number {
    if (nivel >= MILHAO_NIVEIS - 1)
        return 0;
    return Math.floor(acumulado / 2);
}
export function milhaoTier(nivel: number): 'facil' | 'medio' | 'dificil' {
    if (nivel <= 5)
        return 'facil';
    if (nivel <= 11)
        return 'medio';
    return 'dificil';
}
