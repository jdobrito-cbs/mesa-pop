export type GGCategoria = 'geo' | 'hist' | 'cien' | 'esp' | 'arte' | 'ent';
export interface GGCatInfo {
    id: GGCategoria;
    nome: string;
    icone: string;
    cor: string;
}
export const GG_CATEGORIAS: GGCatInfo[] = [
    { id: 'geo', nome: 'Geografia', icone: '🌎', cor: '#22d3ee' },
    { id: 'hist', nome: 'História', icone: '📜', cor: '#f59e0b' },
    { id: 'cien', nome: 'Ciência', icone: '🔬', cor: '#34d399' },
    { id: 'esp', nome: 'Esportes', icone: '⚽', cor: '#facc15' },
    { id: 'arte', nome: 'Arte & Cultura', icone: '🎭', cor: '#ff3ea5' },
    { id: 'ent', nome: 'Entretenimento', icone: '🎬', cor: '#a855f7' },
];
export const GG_META = 6;
export type GGFase = 'escolhendo' | 'pergunta' | 'fim';
export interface GGUltimo {
    seat: number;
    categoria: GGCategoria;
    acertou: boolean;
    ganhouCoroa: boolean;
    respostaCerta: string;
}
export interface GGView {
    fase: GGFase;
    turn: number;
    players: number;
    coroas: GGCategoria[][];
    categoria: GGCategoria | null;
    pergunta: {
        texto: string;
        opcoes: string[];
    } | null;
    ultimo: GGUltimo | null;
    winnerSeats: number[];
}
export type GGAction = {
    type: 'girar';
} | {
    type: 'responder';
    opcao: number;
};
export const catInfo = (id: GGCategoria): GGCatInfo => GG_CATEGORIAS.find((c) => c.id === id)!;
