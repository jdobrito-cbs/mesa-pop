export const FORCA_MAX_ERROS = 6;
export type ForcaFase = 'escolhendo' | 'jogando' | 'fim';
export type ForcaAction = {
    type: 'palavra';
    palavra: string;
} | {
    type: 'letra';
    letra: string;
} | {
    type: 'chute';
    palavra: string;
};
export interface ForcaView {
    fase: ForcaFase;
    players: number;
    rodada: number;
    totalRodadas: number;
    escolhedor: number;
    palavraVista: Array<string | null>;
    letrasErradas: string[];
    letrasCertas: string[];
    erros: number;
    maxErros: number;
    turno: number;
    pontos: number[];
    ultimoEvento: string | null;
    vencedores: number[];
}
export function normalizaForca(s: string): string {
    return s
        .toUpperCase()
        .normalize('NFD')
        .replace(/[̀-ͯ]/g, '')
        .replace(/[^A-Z]/g, '');
}
