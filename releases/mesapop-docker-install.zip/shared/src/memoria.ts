export const MEMORIA_ICONES = [
    '🍉', '🚀', '🐙', '🎲', '🌵', '🎸', '🍩', '⚽', '🦜',
    '🎈', '🐳', '🍕', '⭐', '🦖', '🎯', '🐞', '🌈', '🎁',
] as const;
export const MEMORIA_COLS = 6;
export const MEMORIA_ROWS = 6;
export interface MemoriaCarta {
    estado: 'oculta' | 'virada' | 'presa';
    valor?: number;
    dono?: number;
}
export interface MemoriaView {
    players: number;
    cartas: MemoriaCarta[];
    turno: number;
    pares: number[];
    ultimaJogada: {
        a: number;
        b: number;
        va: number;
        vb: number;
        acertou: boolean;
    } | null;
    fim: boolean;
    vencedores: number[];
}
export type MemoriaAction = {
    type: 'virar';
    index: number;
};
