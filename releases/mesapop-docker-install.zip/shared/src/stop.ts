export const STOP_CATEGORIAS = ['Nome', 'Animal', 'Fruta', 'Cor', 'Objeto', 'Lugar', 'Profissão'] as const;
export type StopFase = 'preenchendo' | 'resultado' | 'fim';
export interface StopResultadoLinha {
    seat: number;
    respostas: string[];
    pontos: number[];
    total: number;
}
export interface StopView {
    fase: StopFase;
    rodada: number;
    totalRodadas: number;
    letra: string;
    tempo: number;
    minhas: string[];
    progresso: Array<{
        seat: number;
        preenchidas: number;
    }>;
    stopPor: number | null;
    resultado: StopResultadoLinha[] | null;
    scores: number[];
    vencedores: number[];
}
export const STOP_TEMPO_RODADA = 90;
export const STOP_TEMPO_RESULTADO = 12;
export const STOP_RODADAS = 4;
export function normalizaResposta(s: string): string {
    return s
        .toLowerCase()
        .normalize('NFD')
        .replace(/[̀-ͯ]/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}
