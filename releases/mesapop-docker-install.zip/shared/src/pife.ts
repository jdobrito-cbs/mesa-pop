export type PifeNaipe = 'o' | 'e' | 'c' | 'p';
export interface PifeCard {
    r: number;
    s: PifeNaipe;
}
export const PIFE_NAIPES: PifeNaipe[] = ['o', 'e', 'c', 'p'];
export type PifeFase = 'comprando' | 'descartando' | 'fim';
export type PifeAction = {
    type: 'monte';
} | {
    type: 'lixo';
} | {
    type: 'descartar';
    index: number;
} | {
    type: 'bater';
};
export interface PifeView {
    fase: PifeFase;
    players: number;
    minhaMao: PifeCard[];
    cartasRestantes: number[];
    monte: number;
    lixoTopo: PifeCard | null;
    lixo: number;
    turno: number;
    presaDoLixo: number | null;
    podeBater: boolean;
    vencedor: number | null;
    gruposVencedores: PifeCard[][] | null;
}
export function isTrinca(cards: PifeCard[]): boolean {
    return cards.length === 3 && cards.every((c) => c.r === cards[0]!.r);
}
export function isSequencia(cards: PifeCard[]): boolean {
    if (cards.length !== 3)
        return false;
    if (!cards.every((c) => c.s === cards[0]!.s))
        return false;
    const rs = cards.map((c) => c.r).sort((a, b) => a - b);
    if (rs[1] === rs[0]! + 1 && rs[2] === rs[1]! + 1)
        return true;
    return rs[0] === 1 && rs[1] === 12 && rs[2] === 13;
}
export function isJogo(cards: PifeCard[]): boolean {
    return isTrinca(cards) || isSequencia(cards);
}
export function particiona9(cards: PifeCard[]): PifeCard[][] | null {
    if (cards.length !== 9)
        return null;
    const idx = [0, 1, 2, 3, 4, 5, 6, 7, 8];
    for (let a1 = 1; a1 < 8; a1++) {
        for (let a2 = a1 + 1; a2 < 9; a2++) {
            const g1 = [0, a1, a2];
            if (!isJogo(g1.map((i) => cards[i]!)))
                continue;
            const resto = idx.filter((i) => !g1.includes(i));
            for (let b1 = 1; b1 < 5; b1++) {
                for (let b2 = b1 + 1; b2 < 6; b2++) {
                    const g2 = [resto[0]!, resto[b1]!, resto[b2]!];
                    if (!isJogo(g2.map((i) => cards[i]!)))
                        continue;
                    const g3 = resto.filter((i) => !g2.includes(i));
                    if (isJogo(g3.map((i) => cards[i]!))) {
                        return [g1, g2, g3].map((g) => g.map((i) => cards[i]!));
                    }
                }
            }
        }
    }
    return null;
}
export function melhorBatida(cards: PifeCard[], descarteProibido: number | null = null): {
    descarte: number;
    grupos: PifeCard[][];
} | null {
    if (cards.length !== 10)
        return null;
    for (let d = 0; d < 10; d++) {
        if (d === descarteProibido)
            continue;
        const grupos = particiona9(cards.filter((_, i) => i !== d));
        if (grupos)
            return { descarte: d, grupos };
    }
    return null;
}
