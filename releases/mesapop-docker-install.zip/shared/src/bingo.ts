export const BINGO_COLUNAS = ['B', 'I', 'N', 'G', 'O'] as const;
export const BINGO_INTERVALO = 3.5;
export type BingoFase = 'sorteando' | 'fim';
export type BingoAction = {
    type: 'marcar';
    index: number;
} | {
    type: 'bingo';
};
export interface BingoView {
    fase: BingoFase;
    players: number;
    bolaAtual: number | null;
    bolas: number[];
    proximaEm: number;
    minhaCartela: number[];
    minhasMarcadas: boolean[];
    rivais: Array<{
        seat: number;
        marcadas: number;
    }>;
    vencedor: number | null;
    linhaVencedora: number[] | null;
}
export function bingoLetra(bola: number): string {
    return BINGO_COLUNAS[Math.min(4, Math.floor((bola - 1) / 15))]!;
}
export const BINGO_LINHAS: number[][] = [
    ...Array.from({ length: 5 }, (_, r) => [0, 1, 2, 3, 4].map((c) => r * 5 + c)),
    ...Array.from({ length: 5 }, (_, c) => [0, 1, 2, 3, 4].map((r) => r * 5 + c)),
    [0, 6, 12, 18, 24],
    [4, 8, 12, 16, 20],
];
