export const RACE_W = 960;
export const RACE_H = 560;
export type VehicleKind = 'carro' | 'moto';
export interface VehicleSpec {
    accel: number;
    brake: number;
    maxSpeed: number;
    boostMaxSpeed: number;
    boostAccel: number;
    steer: number;
    grip: number;
    driftGrip: number;
    centrifugal: number;
}
export const VEHICLES: Record<VehicleKind, VehicleSpec> = {
    carro: {
        accel: 165, brake: 380, maxSpeed: 280, boostMaxSpeed: 400, boostAccel: 330,
        steer: 10, grip: 6, driftGrip: 1.5, centrifugal: 5.5,
    },
    moto: {
        accel: 190, brake: 340, maxSpeed: 300, boostMaxSpeed: 430, boostAccel: 370,
        steer: 11.5, grip: 4.4, driftGrip: 1.05, centrifugal: 6.6,
    },
};
export interface CarState {
    dist: number;
    lat: number;
    latV: number;
    speed: number;
    boostMeter: number;
    boosting: boolean;
    drifting: boolean;
    lap: number;
    nextCheckpoint: number;
    finished: boolean;
    finishTime: number | null;
}
export interface CarInputState {
    seq: number;
    steer: number;
    brake: boolean;
    drift: boolean;
    boost: boolean;
}
export const TOTAL_LAPS = 3;
export interface RacingSnapshot {
    phase: 'countdown' | 'racing' | 'finished';
    countdown: number;
    raceTime: number;
    totalLaps: number;
    vehicle: VehicleKind;
    cars: CarState[];
    lastAck: number[];
    finishOrder: number[];
}
export interface TrackSegment {
    length: number;
    curve: number;
    hill: number;
    start: number;
    elev: number;
}
export const CURVE_K = 620;
const RAW: Array<{
    length: number;
    curve: number;
    hill: number;
}> = [
    { length: 640, curve: 0, hill: 0 },
    { length: 420, curve: 1.3, hill: 0 },
    { length: 260, curve: 0, hill: 0.9 },
    { length: 340, curve: 1.7, hill: 0 },
    { length: 260, curve: 0, hill: -0.9 },
    { length: 300, curve: -1.5, hill: 0 },
    { length: 200, curve: 0, hill: 0 },
    { length: 220, curve: -1.8, hill: 0 },
    { length: 220, curve: 1.8, hill: 0 },
    { length: 320, curve: 0, hill: 0.7 },
    { length: 380, curve: 1.6, hill: 0 },
    { length: 320, curve: 0, hill: -0.7 },
    { length: 420, curve: 1.5, hill: 0 },
    { length: 500, curve: 0, hill: 0 },
];
const rawTurn = RAW.reduce((sum, s) => sum + s.curve * s.length, 0);
export const CURVE_SCALE = (Math.PI * 2 * CURVE_K) / rawTurn;
export const TRACK_SEGMENTS: TrackSegment[] = (() => {
    const out: TrackSegment[] = [];
    let start = 0;
    let elev = 0;
    for (const s of RAW) {
        out.push({ length: s.length, curve: s.curve * CURVE_SCALE, hill: s.hill, start, elev });
        start += s.length;
        elev += s.hill * s.length;
    }
    return out;
})();
export const TRACK_LENGTH = TRACK_SEGMENTS.reduce((sum, s) => sum + s.length, 0);
export function lapDistance(dist: number): number {
    return ((dist % TRACK_LENGTH) + TRACK_LENGTH) % TRACK_LENGTH;
}
export function segmentAt(dist: number): TrackSegment {
    const d = lapDistance(dist);
    for (let i = TRACK_SEGMENTS.length - 1; i >= 0; i--) {
        if (d >= TRACK_SEGMENTS[i]!.start)
            return TRACK_SEGMENTS[i]!;
    }
    return TRACK_SEGMENTS[0]!;
}
export function curveAt(dist: number): number {
    const d = lapDistance(dist);
    const seg = segmentAt(d);
    const local = d - seg.start;
    const BLEND = 70;
    if (local < BLEND) {
        const prev = segmentAt(d - local - 1);
        const t = local / BLEND;
        return prev.curve + (seg.curve - prev.curve) * t;
    }
    return seg.curve;
}
export function elevationAt(dist: number): number {
    const d = lapDistance(dist);
    const seg = segmentAt(d);
    return seg.elev + seg.hill * (d - seg.start);
}
export function trackLayout(step = 40): Array<[
    number,
    number
]> {
    const pts: Array<[
        number,
        number
    ]> = [];
    let x = 0;
    let y = 0;
    let heading = 0;
    for (let d = 0; d < TRACK_LENGTH; d += step) {
        pts.push([x, y]);
        heading += (curveAt(d) / CURVE_K) * step;
        x += Math.cos(heading) * step;
        y += Math.sin(heading) * step;
    }
    return pts;
}
export const CHECKPOINT_COUNT = 4;
export const ROAD_LIMIT = 1.15;
const LAT_MAX = 2.4;
const LATV_MAX = 3.2;
const SLIDE_DRAG = 0.05;
const GRASS_DRAG = 2.2;
const DRIFT_STEER_BONUS = 1.35;
const BOOST_STEER_CUT = 0.45;
const BOOST_DRAIN = 0.55;
const BOOST_CHARGE = 0.55;
const DRIFT_CHARGE_MIN_SLIDE = 1.1;
export function startPose(seat: number): {
    dist: number;
    lat: number;
} {
    return {
        dist: -46 - Math.floor(seat / 2) * 60,
        lat: (seat % 2 === 0 ? -1 : 1) * 0.45,
    };
}
export function initialCar(seat: number): CarState {
    const pose = startPose(seat);
    return {
        dist: pose.dist,
        lat: pose.lat,
        latV: 0,
        speed: 0,
        boostMeter: 0,
        boosting: false,
        drifting: false,
        lap: 0,
        nextCheckpoint: 0,
        finished: false,
        finishTime: null,
    };
}
export function isOnRoad(lat: number): boolean {
    return Math.abs(lat) <= ROAD_LIMIT;
}
export function stepCar(car: CarState, input: CarInputState, dt: number, vehicle: VehicleKind = 'carro'): CarState {
    const c = { ...car };
    const spec = VEHICLES[vehicle];
    if (c.finished) {
        c.speed = Math.max(c.speed - spec.brake * 0.6 * dt, 0);
        c.latV *= Math.max(1 - spec.grip * dt, 0);
        c.lat += c.latV * dt;
        c.dist += c.speed * dt;
        return c;
    }
    const onRoad = isOnRoad(c.lat);
    const speedFactor = Math.min(c.speed / spec.maxSpeed, 1);
    const wantBoost = input.boost && c.boostMeter > 0.15;
    c.boosting = wantBoost;
    if (c.boosting)
        c.boostMeter = Math.max(0, c.boostMeter - BOOST_DRAIN * dt);
    c.drifting = input.drift && c.speed > 100;
    let steerForce = spec.steer;
    if (c.drifting)
        steerForce *= DRIFT_STEER_BONUS;
    if (c.boosting)
        steerForce *= BOOST_STEER_CUT;
    c.latV += input.steer * steerForce * speedFactor * dt;
    const rawCurve = curveAt(c.dist) / CURVE_SCALE;
    c.latV -= rawCurve * spec.centrifugal * speedFactor * speedFactor * dt;
    const grip = c.drifting ? spec.driftGrip : spec.grip;
    c.latV *= Math.max(1 - grip * dt, 0);
    c.latV = Math.max(-LATV_MAX, Math.min(LATV_MAX, c.latV));
    if (c.drifting && Math.abs(c.latV) > DRIFT_CHARGE_MIN_SLIDE) {
        c.boostMeter = Math.min(1, c.boostMeter + BOOST_CHARGE * dt);
    }
    c.lat = Math.max(-LAT_MAX, Math.min(LAT_MAX, c.lat + c.latV * dt));
    if (input.brake) {
        c.speed = Math.max(c.speed - spec.brake * dt, 0);
    }
    else {
        c.speed += (c.boosting ? spec.boostAccel : spec.accel) * dt;
    }
    c.speed *= Math.max(1 - Math.abs(c.latV) * SLIDE_DRAG * dt, 0);
    let maxSpeed = c.boosting ? spec.boostMaxSpeed : spec.maxSpeed;
    if (!onRoad) {
        c.speed *= Math.max(1 - GRASS_DRAG * dt, 0);
        maxSpeed *= 0.5;
    }
    c.speed = Math.min(c.speed, maxSpeed);
    c.dist += c.speed * dt;
    const target = c.lap * TRACK_LENGTH + ((c.nextCheckpoint + 1) * TRACK_LENGTH) / CHECKPOINT_COUNT;
    if (c.dist >= target) {
        c.nextCheckpoint++;
        if (c.nextCheckpoint >= CHECKPOINT_COUNT) {
            c.nextCheckpoint = 0;
            c.lap++;
        }
    }
    return c;
}
export function raceProgress(car: CarState): number {
    return car.dist;
}
