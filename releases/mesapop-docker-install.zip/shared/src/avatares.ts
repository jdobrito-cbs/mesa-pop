import { hashSeed, intAte, mulberry32 } from './seed.js';
export type AvatarTier = 'normal' | 'especial' | 'super';
export type AvatarTipo = 'pessoa' | 'bicho' | 'icone' | 'mascote';
export type AvatarExpressao = 'sorriso' | 'serio' | 'bravo';
export const AVATAR_BICHOS = ['leao', 'panda', 'raposa', 'urso', 'coruja', 'gato', 'cachorro', 'coelho'] as const;
export const AVATAR_ICONES = ['controle', 'joystick', 'dado', 'trofeu', 'foguete', 'bomba', 'bau', 'pocao', 'coroa', 'ficha', 'coracao', 'estrela'] as const;
export const AVATAR_MASCOTES = ['leao', 'coruja', 'ninja', 'caveira', 'fenix', 'robo', 'touro', 'dragao', 'lobo', 'tubarao', 'aguia', 'samurai'] as const;
export interface AvatarParams {
    tier: AvatarTier;
    tipo: AvatarTipo;
    variante: number;
    expressao: AvatarExpressao;
    pele: string;
    cabelo: string;
    corBase: string;
    corSec: string;
    fundo: string;
    oculos: boolean;
    acessorio: number;
    moldura: number;
}
export const AVATAR_FUNDOS = ['#f2695c', '#f7a325', '#57b947', '#2f9e8f', '#3d7dd8', '#7c5cc4', '#e0558f', '#f0c33c', '#5aa8e0', '#8f6c56', '#67b06b', '#d8556b'] as const;
const CORES_VIVAS = ['#ff3ea5', '#22d3ee', '#facc15', '#34d399', '#a855f7', '#fb923c', '#ef4444', '#3b82f6', '#4ade80', '#f59e0b'];
const PELES = ['#ffd9b8', '#f5c09a', '#dfa06e', '#b97a4d', '#8a5a38', '#6b4429'];
const CABELOS = ['#2b2118', '#57351f', '#8a5a2b', '#c98a3a', '#e0b34c', '#c94f2e', '#9c9c9c', '#e8e4da', '#3d6fd8', '#d84f9c'];
const N_NORMAIS = 20;
const N_ESPECIAIS = 1000;
const N_SUPER = 15;
export function avatarTier(id: string): AvatarTier | null {
    const m = /^([nes])(\d{1,4})$/.exec(id);
    if (!m)
        return null;
    const n = Number(m[2]);
    if (m[1] === 'n')
        return n < N_NORMAIS ? 'normal' : null;
    if (m[1] === 'e')
        return n < N_ESPECIAIS ? 'especial' : null;
    return n < N_SUPER ? 'super' : null;
}
export const ehAvatarValido = (id: string): boolean => avatarTier(id) !== null;
export const AVATARES_NORMAIS = Array.from({ length: N_NORMAIS }, (_, i) => `n${i}`);
export const AVATARES_ESPECIAIS = Array.from({ length: N_ESPECIAIS }, (_, i) => `e${i}`);
export const AVATARES_SUPER = Array.from({ length: N_SUPER }, (_, i) => `s${i}`);
export function avatarAleatorioNormal(rnd: () => number = Math.random): string {
    return `n${Math.floor(rnd() * N_NORMAIS)}`;
}
interface NormalDef {
    tipo: 'pessoa' | 'bicho';
    variante: number;
    expressao: AvatarExpressao;
    pele: number;
    cabelo: number;
    fundo: number;
    cor: number;
    oculos?: boolean;
}
const NORMAIS: NormalDef[] = [
    { tipo: 'pessoa', variante: 0, expressao: 'sorriso', pele: 1, cabelo: 0, fundo: 4, cor: 1 },
    { tipo: 'pessoa', variante: 2, expressao: 'sorriso', pele: 4, cabelo: 0, fundo: 1, cor: 3 },
    { tipo: 'pessoa', variante: 8, expressao: 'sorriso', pele: 0, cabelo: 5, fundo: 2, cor: 5 },
    { tipo: 'pessoa', variante: 4, expressao: 'sorriso', pele: 2, cabelo: 1, fundo: 6, cor: 2 },
    { tipo: 'pessoa', variante: 6, expressao: 'sorriso', pele: 1, cabelo: 7, fundo: 3, cor: 0, oculos: true },
    { tipo: 'pessoa', variante: 1, expressao: 'serio', pele: 3, cabelo: 0, fundo: 7, cor: 7 },
    { tipo: 'pessoa', variante: 3, expressao: 'sorriso', pele: 0, cabelo: 9, fundo: 5, cor: 4, oculos: true },
    { tipo: 'pessoa', variante: 9, expressao: 'sorriso', pele: 2, cabelo: 5, fundo: 0, cor: 8 },
    { tipo: 'pessoa', variante: 10, expressao: 'sorriso', pele: 1, cabelo: 4, fundo: 8, cor: 6 },
    { tipo: 'pessoa', variante: 7, expressao: 'serio', pele: 4, cabelo: 6, fundo: 9, cor: 9, oculos: true },
    { tipo: 'pessoa', variante: 11, expressao: 'sorriso', pele: 5, cabelo: 0, fundo: 10, cor: 1 },
    { tipo: 'pessoa', variante: 5, expressao: 'bravo', pele: 0, cabelo: 8, fundo: 11, cor: 0 },
    { tipo: 'bicho', variante: 0, expressao: 'serio', pele: 0, cabelo: 0, fundo: 1, cor: 2 },
    { tipo: 'bicho', variante: 1, expressao: 'sorriso', pele: 0, cabelo: 0, fundo: 3, cor: 0 },
    { tipo: 'bicho', variante: 2, expressao: 'sorriso', pele: 0, cabelo: 0, fundo: 2, cor: 5 },
    { tipo: 'bicho', variante: 3, expressao: 'serio', pele: 0, cabelo: 0, fundo: 8, cor: 9 },
    { tipo: 'bicho', variante: 4, expressao: 'serio', pele: 0, cabelo: 0, fundo: 5, cor: 1 },
    { tipo: 'bicho', variante: 5, expressao: 'sorriso', pele: 0, cabelo: 0, fundo: 0, cor: 3 },
    { tipo: 'bicho', variante: 6, expressao: 'sorriso', pele: 0, cabelo: 0, fundo: 4, cor: 6 },
    { tipo: 'bicho', variante: 7, expressao: 'sorriso', pele: 0, cabelo: 0, fundo: 6, cor: 7 },
];
const SUPERS: Array<{
    variante: number;
    fundo: number;
}> = [
    { variante: 0, fundo: 1 },
    { variante: 4, fundo: 0 },
    { variante: 7, fundo: 6 },
    { variante: 2, fundo: 3 },
    { variante: 11, fundo: 11 },
    { variante: 1, fundo: 5 },
    { variante: 3, fundo: 9 },
    { variante: 5, fundo: 4 },
    { variante: 6, fundo: 2 },
    { variante: 8, fundo: 8 },
    { variante: 9, fundo: 4 },
    { variante: 10, fundo: 1 },
    { variante: 0, fundo: 7 },
    { variante: 7, fundo: 2 },
    { variante: 4, fundo: 5 },
];
export function paramsFromId(id: string): AvatarParams {
    const tier = avatarTier(id) ?? 'normal';
    const rnd = mulberry32(hashSeed(id || 'n0'));
    if (tier === 'normal' && /^n\d+$/.test(id)) {
        const d = NORMAIS[Number(id.slice(1))]!;
        return {
            tier,
            tipo: d.tipo,
            variante: d.variante,
            expressao: d.expressao,
            pele: PELES[d.pele]!,
            cabelo: CABELOS[d.cabelo]!,
            corBase: CORES_VIVAS[d.cor]!,
            corSec: CORES_VIVAS[(d.cor + 3) % CORES_VIVAS.length]!,
            fundo: AVATAR_FUNDOS[d.fundo]!,
            oculos: !!d.oculos,
            acessorio: 0,
            moldura: 0,
        };
    }
    if (tier === 'super' && /^s\d+$/.test(id)) {
        const d = SUPERS[Number(id.slice(1))]!;
        return {
            tier,
            tipo: 'mascote',
            variante: d.variante,
            expressao: 'bravo',
            pele: PELES[0]!,
            cabelo: CABELOS[0]!,
            corBase: CORES_VIVAS[intAte(rnd, CORES_VIVAS.length)]!,
            corSec: CORES_VIVAS[intAte(rnd, CORES_VIVAS.length)]!,
            fundo: AVATAR_FUNDOS[d.fundo]!,
            oculos: false,
            acessorio: 1 + intAte(rnd, 5),
            moldura: 1 + intAte(rnd, 4),
        };
    }
    const especial = tier === 'especial';
    const tipo: AvatarTipo = especial
        ? intAte(rnd, 2) === 0 ? 'icone' : 'mascote'
        : intAte(rnd, 2) === 0 ? 'pessoa' : 'bicho';
    const nVar = tipo === 'pessoa' ? 12 : tipo === 'bicho' ? AVATAR_BICHOS.length : tipo === 'icone' ? AVATAR_ICONES.length : AVATAR_MASCOTES.length;
    const exps: AvatarExpressao[] = tipo === 'mascote' ? ['bravo', 'serio'] : ['sorriso', 'sorriso', 'serio', 'bravo'];
    return {
        tier,
        tipo,
        variante: intAte(rnd, nVar),
        expressao: exps[intAte(rnd, exps.length)]!,
        pele: PELES[intAte(rnd, PELES.length)]!,
        cabelo: CABELOS[intAte(rnd, CABELOS.length)]!,
        corBase: CORES_VIVAS[intAte(rnd, CORES_VIVAS.length)]!,
        corSec: CORES_VIVAS[intAte(rnd, CORES_VIVAS.length)]!,
        fundo: AVATAR_FUNDOS[intAte(rnd, AVATAR_FUNDOS.length)]!,
        oculos: intAte(rnd, 5) === 0,
        acessorio: especial ? 1 + intAte(rnd, 5) : 0,
        moldura: 0,
    };
}
