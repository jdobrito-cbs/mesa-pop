export const QUIZ_RODADAS = 10;
export const QUIZ_TEMPO_PERGUNTA = 15;
export const QUIZ_TEMPO_REVELACAO = 4;
export const QUIZ_PONTOS_BASE = 100;
export const QUIZ_BONUS_RAPIDEZ = 50;
export type QuizFase = 'pergunta' | 'revelacao' | 'fim';
export type QuizAction = {
    type: 'resposta';
    index: number;
};
export interface QuizView {
    fase: QuizFase;
    players: number;
    rodada: number;
    totalRodadas: number;
    categoria: string;
    pergunta: string;
    alternativas: string[];
    tempoRestante: number;
    minhaResposta: number | null;
    responderam: boolean[];
    correta: number | null;
    respostas: Array<number | null> | null;
    ganhoUltima: number[];
    placar: number[];
    vencedores: number[];
}
