export interface RankingGeralRow {
    rank: number;
    userId: string;
    displayName: string;
    avatar: string | null;
    valor: number;
}
export interface RankingsGerais {
    pontos: RankingGeralRow[];
    tempo: RankingGeralRow[];
    voce: {
        pontos: number | null;
        tempo: number | null;
    } | null;
}
