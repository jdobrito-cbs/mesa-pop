import { CISCO_APOSTAS_MS, CISCO_CAUDA_MS, CISCO_CERIMONIA_MS, CISCO_CORRIDA_MS, CISCO_GALINHAS, CISCO_PRELARGADA_MS, ciscoBuildRace, } from '@mesapop/shared';
import type { GameModule } from './module';
import { avancaCicloCorrida, novaCorrida, viewDeCorrida, type CorridaConfig, type CorridaState, } from './corridaCiclo';
export type CiscoState = CorridaState;
function config(): CorridaConfig {
    return {
        apostasMs: Number(process.env.CISCO_APOSTAS_MS ?? CISCO_APOSTAS_MS),
        prelargadaMs: Number(process.env.CISCO_PRELARGADA_MS ?? CISCO_PRELARGADA_MS),
        corridaMs: CISCO_CORRIDA_MS,
        cerimoniaMs: CISCO_CERIMONIA_MS,
        caudaMs: CISCO_CAUDA_MS,
        resultadoDe(seed) {
            const r = ciscoBuildRace(seed);
            return { vencedor: r.vencedor, winCrossT: r.winCrossT };
        },
        nomeDe: (lane) => CISCO_GALINHAS[lane]!.nome,
    };
}
export function novoCisco(numero: number, historico: string[], agora = Date.now()): CiscoState {
    return novaCorrida(config(), numero, historico, agora);
}
export function avancaCicloCisco(s: CiscoState, agora = Date.now()): void {
    avancaCicloCorrida(config(), s, agora);
}
export const ciscoModule: GameModule<CiscoState, unknown> = {
    slug: 'cisco',
    minPlayers: 1,
    maxPlayers: 16,
    allowSpectators: true,
    dropIn: true,
    realtime: { tickMs: 500, broadcastEvery: 4 },
    init() {
        return novoCisco(1, []);
    },
    tick(state) {
        avancaCicloCisco(state);
    },
    play() {
        return { error: 'Aposte pelo painel de apostas (fora do turno de ações)' };
    },
    getStateFor(state) {
        return viewDeCorrida(state);
    },
    result() {
        return { finished: false, winnerSeats: [], draw: false };
    },
};
