export interface GameModule<S = unknown, A = unknown> {
    slug: string;
    minPlayers: number;
    maxPlayers: number;
    validPlayerCounts?: number[];
    seatPicking?: boolean;
    allowSpectators?: boolean;
    rotation?: boolean;
    dropIn?: boolean;
    realtime?: {
        tickMs: number;
        broadcastEvery: number;
        perSeatView?: boolean;
    };
    init(playerCount: number, options?: Record<string, unknown>): S;
    play(state: S, seat: number, action: A): {
        error: string;
    } | {
        state: S;
    };
    getStateFor(state: S, seat: number): unknown;
    tick?(state: S, dt: number): void;
    currentSeat?(state: S): number | null;
    bot?(state: S, seat: number): A | null;
    botDelayMs?: number;
    botTick?(state: S, botSeats: number[], dt: number): void;
    scoresFor?(state: S): number[];
    result(state: S): {
        finished: boolean;
        winnerSeats: number[];
        draw: boolean;
    };
}
const registry = new Map<string, GameModule>();
export function registerGame(module: GameModule) {
    registry.set(module.slug, module);
}
export function getGameModule(slug: string): GameModule | undefined {
    return registry.get(slug);
}
