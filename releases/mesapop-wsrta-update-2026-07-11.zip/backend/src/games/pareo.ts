import { PAREO_APOSTAS_MS, PAREO_CAUDA_MS, PAREO_CAVALOS, PAREO_CERIMONIA_MS, PAREO_CORRIDA_MS, PAREO_PRELARGADA_MS, pareoBuildRace, } from '@mesapop/shared';
import type { GameModule } from './module';
import { avancaCicloCorrida, novaCorrida, viewDeCorrida, type CorridaConfig, type CorridaState, } from './corridaCiclo';
export type PareoState = CorridaState;
function config(): CorridaConfig {
    return {
        apostasMs: Number(process.env.PAREO_APOSTAS_MS ?? PAREO_APOSTAS_MS),
        prelargadaMs: Number(process.env.PAREO_PRELARGADA_MS ?? PAREO_PRELARGADA_MS),
        corridaMs: PAREO_CORRIDA_MS,
        cerimoniaMs: PAREO_CERIMONIA_MS,
        caudaMs: PAREO_CAUDA_MS,
        resultadoDe(seed) {
            const r = pareoBuildRace(seed);
            return { vencedor: r.vencedor, winCrossT: r.winCrossT };
        },
        nomeDe: (lane) => PAREO_CAVALOS[lane]!.nome,
    };
}
export function novoPareo(numero: number, historico: string[], agora = Date.now()): PareoState {
    return novaCorrida(config(), numero, historico, agora);
}
export function avancaCiclo(s: PareoState, agora = Date.now()): void {
    avancaCicloCorrida(config(), s, agora);
}
export const pareoModule: GameModule<PareoState, unknown> = {
    slug: 'pareo',
    minPlayers: 1,
    maxPlayers: 16,
    allowSpectators: true,
    dropIn: true,
    realtime: { tickMs: 500, broadcastEvery: 4 },
    init() {
        return novoPareo(1, []);
    },
    tick(state) {
        avancaCiclo(state);
    },
    play() {
        return { error: 'Aposte pelo painel de apostas (fora do turno de ações)' };
    },
    getStateFor(state) {
        return viewDeCorrida(state);
    },
    result() {
        return { finished: false, winnerSeats: [], draw: false };
    },
};
